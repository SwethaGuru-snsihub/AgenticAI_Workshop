import streamlit as st
import PyPDF2
import json
import plotly.graph_objects as go
import plotly.express as px
from io import BytesIO
from rag_utils import get_market_justification, get_candidate_scorecard, OfferPersonalizationAgent
from offer_logic import parse_resume_text, generate_market_aligned_offer, CandidateProfile

# Page configuration
st.set_page_config(
    page_title="Intelligent Offer Personalizer", 
    page_icon="💼", 
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #667eea;
    }
    .candidate-profile {
        background: #e3f2fd;
        padding: 1.5rem;
        border-radius: 10px;
        margin: 1rem 0;
    }
    .offer-summary {
        background: #f3e5f5;
        padding: 1.5rem;
        border-radius: 10px;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Main header
st.markdown("""
<div class="main-header">
    <h1>💼 Intelligent Offer Personalizer</h1>
    <p>AI-Powered Compensation Analysis & Market-Aligned Offer Generation</p>
</div>
""", unsafe_allow_html=True)

# Initialize session state
if 'candidate_profile' not in st.session_state:
    st.session_state.candidate_profile = None
if 'generated_offer' not in st.session_state:
    st.session_state.generated_offer = None
if 'agent' not in st.session_state:
    try:
        st.session_state.agent = OfferPersonalizationAgent()
    except Exception as e:
        st.error(f"Failed to initialize AI agent: {e}")
        st.info("Please ensure GOOGLE_API_KEY is set in your environment variables.")

def extract_pdf_text(uploaded_file) -> str:
    """Extract text from uploaded PDF"""
    try:
        reader = PyPDF2.PdfReader(uploaded_file)
        text = ""
        for page in reader.pages:
            text += page.extract_text() or ""
        return text
    except Exception as e:
        st.error(f"Error reading PDF: {e}")
        return ""

def display_candidate_profile(profile: CandidateProfile):
    """Display candidate profile in a formatted way"""
    st.markdown('<div class="candidate-profile">', unsafe_allow_html=True)
    st.subheader("👤 Candidate Profile Analysis")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Name", profile.name)
        st.metric("Experience", f"{profile.experience} years")
        st.metric("Company Tier", profile.company_tier.title())
    
    with col2:
        st.write("**Previous Companies:**")
        for company in profile.previous_companies[:3]:
            st.write(f"• {company}")
        
        st.write("**Location:**")
        st.write(profile.location or "Not specified")
    
    with col3:
        st.write("**Key Skills:**")
        for skill in profile.skills[:8]:
            st.write(f"• {skill}")
        
        if profile.education:
            st.write("**Education:**")
            for edu in profile.education[:3]:
                st.write(f"• {edu}")
    
    st.markdown('</div>', unsafe_allow_html=True)

def create_compensation_chart(offer: dict):
    """Create compensation breakdown chart"""
    if 'components_breakdown' in offer:
        components = offer['components_breakdown']
        
        # Pie chart for compensation breakdown
        labels = ['Base Salary', 'Variable Comp', 'Signing Bonus']
        values = [
            components.get('base_percentage', 0),
            components.get('variable_percentage', 0), 
            components.get('bonus_percentage', 0)
        ]
        
        fig = go.Figure(data=[go.Pie(
            labels=labels, 
            values=values,
            hole=0.4,
            marker_colors=['#667eea', '#764ba2', '#f093fb']
        )])
        
        fig.update_layout(
            title="Compensation Breakdown",
            font=dict(size=14),
            showlegend=True
        )
        
        return fig
    return None

def create_market_comparison_chart(offer: dict):
    """Create market comparison chart"""
    try:
        recommended = offer.get('total_compensation_range', {}).get('recommended', 0) / 100000
        min_comp = offer.get('total_compensation_range', {}).get('min', 0) / 100000
        max_comp = offer.get('total_compensation_range', {}).get('max', 0) / 100000
        
        fig = go.Figure()
        
        # Add bar for compensation range
        fig.add_trace(go.Bar(
            x=['Market Range'],
            y=[max_comp - min_comp],
            base=[min_comp],
            name='Range',
            marker_color='lightblue',
            opacity=0.6
        ))
        
        # Add recommended point
        fig.add_trace(go.Scatter(
            x=['Market Range'],
            y=[recommended],
            mode='markers',
            name='Recommended',
            marker=dict(size=15, color='red', symbol='diamond')
        ))
        
        fig.update_layout(
            title="Market Position Analysis",
            yaxis_title="Total Compensation (LPA)",
            xaxis_title="",
            showlegend=True
        )
        
        return fig
    except:
        return None

def display_scorecard(scorecard: dict):
    """Display candidate scorecard"""
    st.subheader("📊 Candidate Strength & Market Alignment Scorecard")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Candidate Strength Metrics:**")
        strength = scorecard.get('candidate_strength', {})
        
        # Progress bars for strength metrics
        st.write("Experience Score:")
        st.progress(strength.get('experience_score', 0) / 100)
        
        st.write("Skills Score:")
        st.progress(strength.get('skills_score', 0) / 100)
        
        st.write("Company Tier Score:")
        st.progress(strength.get('company_tier_score', 0) / 100)
        
        st.write("Education Score:")
        st.progress(strength.get('education_score', 0) / 100)
    
    with col2:
        st.write("**Market Alignment:**")
        alignment = scorecard.get('market_alignment', {})
        
        st.metric("Salary Percentile", alignment.get('salary_percentile', 'N/A'))
        st.metric("Market Competitiveness", alignment.get('market_competitiveness', 'N/A'))
        st.metric("Premium Applied", alignment.get('premium_applied', '0%'))
        
        st.write("**Overall Score:**")
        overall_score = scorecard.get('overall_score', 0)
        st.metric("Overall Rating", f"{overall_score}/100")

# Sidebar for navigation
with st.sidebar:
    st.header("Navigation")
    page = st.selectbox(
        "Choose a step:",
        ["1. Upload Resume", "2. Generate Offer", "3. AI Analysis", "4. Market Intelligence"]
    )

# Main content based on page selection
if page == "1. Upload Resume":
    st.header("📄 Resume Upload & Analysis")
    
    uploaded_file = st.file_uploader(
        "Upload candidate resume (PDF only)", 
        type=["pdf"],
        help="Upload a PDF resume for automatic parsing and analysis"
    )
    
    if uploaded_file:
        with st.spinner("Analyzing resume..."):
            # Extract text
            resume_text = extract_pdf_text(uploaded_file)
            
            if resume_text:
                # Parse resume
                profile = parse_resume_text(resume_text)
                st.session_state.candidate_profile = profile
                
                # Display parsed information
                display_candidate_profile(profile)
                
                # Show raw text preview
                with st.expander("📋 Extracted Resume Text (Preview)"):
                    st.text_area("Raw Text", resume_text[:1000] + "..." if len(resume_text) > 1000 else resume_text, height=200)
                
                st.success("✅ Resume analyzed successfully! Proceed to Generate Offer.")
            else:
                st.error("Failed to extract text from PDF. Please try a different file.")

elif page == "2. Generate Offer":
    st.header("💰 Generate Market-Aligned Offer")
    
    if st.session_state.candidate_profile is None:
        st.warning("⚠️ Please upload and analyze a resume first.")
    else:
        profile = st.session_state.candidate_profile
        
        # Offer generation inputs
        col1, col2, col3 = st.columns(3)
        
        with col1:
            target_role = st.selectbox(
                "Target Role",
                ["Software Engineer", "Software Engineer II", "Senior Software Engineer", "Staff Software Engineer"]
            )
        
        with col2:
            target_company = st.selectbox(
                "Target Company",
                ["Google", "Microsoft", "Amazon", "Meta", "Netflix", "Uber", "Flipkart", "Razorpay", "Paytm", "Other"]
            )
        
        with col3:
            target_location = st.selectbox(
                "Target Location", 
                ["Bangalore", "Mumbai", "Delhi", "Hyderabad", "Chennai", "Pune"]
            )
        
        # Update profile with selections
        profile.current_role = target_role
        profile.current_company = target_company
        profile.location = target_location
        
        if st.button("🚀 Generate Offer", type="primary"):
            with st.spinner("Generating market-aligned offer..."):
                try:
                    offer = generate_market_aligned_offer(profile, target_role, target_company, target_location)
                    st.session_state.generated_offer = offer
                    
                    # Display offer summary
                    st.markdown('<div class="offer-summary">', unsafe_allow_html=True)
                    st.subheader("🎯 Generated Offer Summary")
                    
                    # Main metrics
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        base_salary = offer.get('base_salary_range', {}).get('recommended', 0)
                        st.metric("Base Salary", f"₹{base_salary/100000:.1f} LPA")
                    
                    with col2:
                        total_comp = offer.get('total_compensation_range', {}).get('recommended', 0)
                        st.metric("Total Compensation", f"₹{total_comp/100000:.1f} LPA")
                    
                    with col3:
                        market_pos = offer.get('market_position', 'Competitive')
                        st.metric("Market Position", market_pos)
                    
                    # Additional components
                    st.write("**Additional Components:**")
                    comp_col1, comp_col2, comp_col3 = st.columns(3)
                    
                    with comp_col1:
                        signing_bonus = offer.get('signing_bonus', 0)
                        st.write(f"Signing Bonus: ₹{signing_bonus/100000:.1f} L")
                    
                    with comp_col2:
                        annual_bonus = offer.get('annual_bonus', 0)
                        st.write(f"Annual Bonus: ₹{annual_bonus/100000:.1f} L")
                    
                    with comp_col3:
                        stock_grant = offer.get('stock_grant', 0)
                        st.write(f"Stock Grant: ₹{stock_grant/100000:.1f} L")
                    
                    # Compensation breakdown chart
                    chart = create_compensation_chart(offer)
                    if chart:
                        st.plotly_chart(chart, use_container_width=True)
                    
                    # Market comparison chart
                    market_chart = create_market_comparison_chart(offer)
                    if market_chart:
                        st.plotly_chart(market_chart, use_container_width=True)
                    
                    st.markdown('</div>', unsafe_allow_html=True)
                    
                except Exception as e:
                    st.error(f"Error generating offer: {e}")

elif page == "3. AI Analysis":
    st.header("🤖 AI-Powered Analysis & Justification")
    
    if st.session_state.candidate_profile is None or st.session_state.generated_offer is None:
        st.warning("⚠️ Please complete resume analysis and offer generation first.")
    else:
        profile = st.session_state.candidate_profile
        offer = st.session_state.generated_offer
        
        # Generate scorecard
        if st.button("📊 Generate Candidate Scorecard"):
            with st.spinner("Analyzing candidate strength..."):
                try:
                    scorecard = get_candidate_scorecard(profile, offer)
                    display_scorecard(scorecard)
                except Exception as e:
                    st.error(f"Error generating scorecard: {e}")
        
        # Generate AI justification
        if st.button("💬 Generate AI Justification"):
            with st.spinner("Generating AI-powered market justification..."):
                try:
                    if 'agent' in st.session_state:
                        justification = st.session_state.agent.generate_offer_justification(profile, offer)
                        
                        st.subheader("🎯 Market Justification")
                        st.write(justification)
                        
                        # Download justification
                        st.download_button(
                            label="📥 Download Justification",
                            data=justification,
                            file_name=f"offer_justification_{profile.name.replace(' ', '_')}.txt",
                            mime="text/plain"
                        )
                    else:
                        st.error("AI agent not initialized. Please check your GOOGLE_API_KEY.")
                        
                except Exception as e:
                    st.error(f"Error generating justification: {e}")

elif page == "4. Market Intelligence":
    st.header("📈 Market Intelligence Dashboard")
    
    # Market trends and insights
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Current Market Trends")
        st.write("""
        **2024 Compensation Trends:**
        - Senior roles (5+ years): 15% growth
        - AI/ML skills: 20-25% premium
        - Remote work: 5-10% location premium
        - Stock grants: 25-40% of total comp at tier-1 companies
        """)
        
        st.subheader("🎯 High-Demand Skills")
        skills_data = {
            'Skill': ['System Design', 'Machine Learning', 'Cloud Architecture', 'Kubernetes', 'React/Frontend'],
            'Premium': [15, 20, 12, 10, 8]
        }
        
        fig = px.bar(
            x=skills_data['Premium'], 
            y=skills_data['Skill'],
            orientation='h',
            title="Skill Premium Percentages",
            labels={'x': 'Premium %', 'y': 'Skills'}
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("🏢 Company Tier Analysis")
        tier_data = {
            'Tier': ['Tier 1 (FAANG)', 'Tier 2 (Unicorns)', 'Startups', 'Service Companies'],
            'Avg_Total_Comp': [65, 45, 28, 15]
        }
        
        fig = px.pie(
            values=tier_data['Avg_Total_Comp'],
            names=tier_data['Tier'],
            title="Average Total Compensation by Company Tier (LPA)"
        )
        st.plotly_chart(fig, use_container_width=True)
        
        st.subheader("📍 Location Multipliers")
        location_data = {
            'City': ['Mumbai', 'Delhi', 'Bangalore', 'Pune', 'Hyderabad', 'Chennai'],
            'Multiplier': [1.1, 1.05, 1.0, 0.88, 0.9, 0.85]
        }
        
        fig = px.bar(
            x=location_data['City'],
            y=location_data['Multiplier'],
            title="City-wise Salary Multipliers"
        )
        st.plotly_chart(fig, use_container_width=True)

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #666; padding: 1rem;'>
    <p>💼 Intelligent Offer Personalizer | Powered by AI & Market Intelligence</p>
    <p>Built with Streamlit, LangChain, and Gemini AI</p>
</div>
""", unsafe_allow_html=True)