Install dependencies:
 # pip install -r requirements.txt

 Create a `.env` file:
 # GOOGLE_API_KEY=your-gemini-api-key

 Run the app:
# streamlit run app.py

NOTE - Rename salary_data as "enhanced_salary_data" 