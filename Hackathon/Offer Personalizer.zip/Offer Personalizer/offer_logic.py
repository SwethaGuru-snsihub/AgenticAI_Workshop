import re
from typing import List, Dict, Optional
import json
from dataclasses import dataclass
from datetime import datetime

@dataclass
class CandidateProfile:
    name: str = ""
    experience: float = 0.0
    current_role: str = ""
    current_company: str = ""
    previous_companies: List[str] = None
    skills: List[str] = None
    location: str = ""
    education: List[str] = None
    certifications: List[str] = None
    company_tier: str = "startup"  # tier1, tier2, startup, service
    
    def __post_init__(self):
        if self.previous_companies is None:
            self.previous_companies = []
        if self.skills is None:
            self.skills = []
        if self.education is None:
            self.education = []
        if self.certifications is None:
            self.certifications = []

# ----------------------
# Enhanced Resume Parsing Logic
# ----------------------
def extract_name_advanced(text: str) -> str:
    """Extract name using multiple strategies"""
    # Strategy 1: Look for name patterns at the beginning
    name_patterns = [
        r'^([A-Z][a-z]+ [A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',  # First line name
        r'Name\s*[:]\s*([A-Za-z\s]+)',  # Name: field
        r'([A-Z][a-z]+\s+[A-Z][a-z]+)',  # Capitalized names
    ]
    
    lines = text.strip().split('\n')
    first_line = lines[0].strip()
    
    # Try first line first
    if re.match(r'^[A-Z][a-z]+\s+[A-Z][a-z]+', first_line):
        return first_line.strip()
    
    # Try patterns
    for pattern in name_patterns:
        match = re.search(pattern, text, re.MULTILINE)
        if match:
            return match.group(1).strip().title()
    
    return "Unknown"

def extract_experience_advanced(text: str) -> float:
    """Extract experience with multiple patterns"""
    patterns = [
        r'(\d+(?:\.\d+)?)\s*(?:\+)?\s*years?\s*(?:of)?\s*experience',
        r'experience\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*(?:\+)?\s*years?',
        r'(\d+)\s*(?:\+)?\s*yrs?\s*(?:of)?\s*(?:experience|exp)',
        r'(?:total|overall)\s*experience\s*[:\-]?\s*(\d+(?:\.\d+)?)',
        r'(\d+)\s*years?\s*in\s*(?:software|development|programming)',
        r'working\s*(?:for|since)\s*(\d+)\s*years?',
    ]
    
    text_lower = text.lower()
    experiences = []
    
    for pattern in patterns:
        matches = re.findall(pattern, text_lower)
        for match in matches:
            try:
                exp = float(match)
                if 0 < exp <= 20:  # Reasonable range
                    experiences.append(exp)
            except:
                continue
    
    if experiences:
        return max(experiences)  # Take the highest reasonable experience
    
    # Fallback: count job durations
    duration_pattern = r'(\d{4})\s*-\s*(?:(\d{4})|present|current)'
    matches = re.findall(duration_pattern, text_lower)
    total_exp = 0
    
    for match in matches:
        start_year = int(match[0])
        end_year = int(match[1]) if match[1] else datetime.now().year
        if 2000 <= start_year <= datetime.now().year:
            total_exp += max(0, end_year - start_year)
    
    return min(total_exp, 20)  # Cap at 20 years

def extract_skills_advanced(text: str) -> List[str]:
    """Extract skills with comprehensive matching"""
    skill_categories = {
        'languages': ['python', 'java', 'javascript', 'typescript', 'c++', 'c#', 'go', 'rust', 'scala', 'kotlin', 'swift', 'php', 'ruby'],
        'frameworks': ['react', 'angular', 'vue', 'node.js', 'express', 'django', 'flask', 'spring', 'hibernate', '.net'],
        'databases': ['mysql', 'postgresql', 'mongodb', 'redis', 'elasticsearch', 'cassandra', 'dynamodb', 'sqlite'],
        'cloud': ['aws', 'azure', 'gcp', 'google cloud', 'amazon web services', 'microsoft azure'],
        'tools': ['docker', 'kubernetes', 'jenkins', 'git', 'gitlab', 'github', 'jira', 'confluence'],
        'concepts': ['machine learning', 'deep learning', 'ai', 'data science', 'system design', 'microservices', 'devops', 'ci/cd']
    }
    
    found_skills = []
    text_lower = text.lower()
    
    for category, skills in skill_categories.items():
        for skill in skills:
            # Use word boundaries to avoid partial matches
            pattern = r'\b' + re.escape(skill.lower()) + r'\b'
            if re.search(pattern, text_lower):
                found_skills.append(skill.title())
    
    return list(set(found_skills))

def extract_companies_advanced(text: str) -> List[str]:
    """Extract company names from resume"""
    # Common company patterns
    company_indicators = [
        r'(?:worked at|employed at|joined)\s+([A-Z][a-zA-Z\s&]+?)(?:\s+as|\s+in|\n)',
        r'([A-Z][a-zA-Z\s&]+?)\s*(?:,\s*)?(?:Bangalore|Mumbai|Delhi|Hyderabad|Chennai|Pune)',
        r'([A-Z][a-zA-Z\s&]+?)\s*(?:\(|\s+\d{4})',
    ]
    
    companies = []
    for pattern in company_indicators:
        matches = re.findall(pattern, text)
        for match in matches:
            company = match.strip()
            if len(company) > 2 and company not in companies:
                companies.append(company)
    
    return companies[:5]  # Limit to 5 most recent

def classify_company_tier(companies: List[str]) -> str:
    """Classify company tier based on company names"""
    tier1_companies = ['google', 'microsoft', 'amazon', 'apple', 'meta', 'netflix', 'uber', 'linkedin', 'twitter', 'salesforce']
    tier2_companies = ['flipkart', 'paytm', 'ola', 'swiggy', 'zomato', 'byjus', 'phonepe', 'cred', 'razorpay']
    service_companies = ['tcs', 'infosys', 'wipro', 'cognizant', 'accenture', 'capgemini', 'hcl', 'tech mahindra']
    
    for company in companies:
        company_lower = company.lower()
        if any(tier1 in company_lower for tier1 in tier1_companies):
            return "tier1"
        elif any(tier2 in company_lower for tier2 in tier2_companies):
            return "tier2"
        elif any(service in company_lower for service in service_companies):
            return "service"
    
    return "startup"

def extract_education(text: str) -> List[str]:
    """Extract educational qualifications"""
    education_patterns = [
        r'(B\.?Tech|Bachelor|B\.?E\.?|M\.?Tech|Master|PhD|B\.?Sc|M\.?Sc|MBA)',
        r'(IIT|IIM|NIT|BITS|VIT|SRM|Manipal)',
        r'(Computer Science|Software Engineering|Information Technology|Electronics)',
    ]
    
    education = []
    for pattern in education_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        education.extend(matches)
    
    return list(set(education))

def parse_resume_text(text: str) -> CandidateProfile:
    """Enhanced resume parsing with multiple extraction strategies"""
    profile = CandidateProfile()
    
    # Extract all information
    profile.name = extract_name_advanced(text)
    profile.experience = extract_experience_advanced(text)
    profile.skills = extract_skills_advanced(text)
    profile.previous_companies = extract_companies_advanced(text)
    profile.education = extract_education(text)
    profile.company_tier = classify_company_tier(profile.previous_companies)
    
    # Set current company and role if available
    if profile.previous_companies:
        profile.current_company = profile.previous_companies[0]
    
    return profile

# ----------------------
# Enhanced Offer Generator with Market Intelligence
# ----------------------
def get_company_multiplier(company: str) -> float:
    """Get company-specific multiplier"""
    multipliers = {
        'google': 1.4, 'microsoft': 1.35, 'amazon': 1.3, 'meta': 1.4, 'netflix': 1.5,
        'uber': 1.25, 'linkedin': 1.3, 'salesforce': 1.25,
        'flipkart': 1.15, 'paytm': 1.1, 'ola': 1.1, 'swiggy': 1.15, 'zomato': 1.1,
        'tcs': 0.8, 'infosys': 0.8, 'wipro': 0.75, 'cognizant': 0.8, 'accenture': 0.85
    }
    
    company_lower = company.lower()
    for comp, mult in multipliers.items():
        if comp in company_lower:
            return mult
    return 1.0

def calculate_total_premium(candidate: CandidateProfile, role: str) -> float:
    """Calculate total premium based on candidate profile"""
    premium = 0.0
    
    # Experience premium
    if candidate.experience > 5:
        premium += 0.1
    if candidate.experience > 8:
        premium += 0.05
    
    # Company tier premium
    tier_premiums = {'tier1': 0.2, 'tier2': 0.1, 'service': -0.1, 'startup': 0.05}
    premium += tier_premiums.get(candidate.company_tier, 0)
    
    # Skills premium
    high_value_skills = ['machine learning', 'system design', 'aws', 'kubernetes', 'microservices']
    skill_matches = [skill for skill in candidate.skills if skill.lower() in [s.lower() for s in high_value_skills]]
    premium += len(skill_matches) * 0.03
    
    # Education premium
    if any('iit' in edu.lower() or 'iim' in edu.lower() for edu in candidate.education):
        premium += 0.05
    
    return min(premium, 0.5)  # Cap at 50%

def generate_market_aligned_offer(candidate: CandidateProfile, role: str, company: str, location: str) -> Dict:
    """Generate market-aligned offer with detailed breakdown"""
    
    # Load market data
    try:
        with open("salary_data.json") as f:
            data = json.load(f)
    except:
        # Fallback data
        data = create_fallback_salary_data()
    
    # Find similar profiles
    exp_range = get_experience_range(candidate.experience)
    similar_profiles = []
    
    for record in data.get("market_data", []):
        if (record.get('role') == role and 
            record.get('location') == location and 
            record.get('experience_range') == exp_range):
            similar_profiles.append(record)
    
    # Fallback to similar roles
    if not similar_profiles:
        similar_profiles = [r for r in data.get("market_data", []) if r.get('role') == role]
    
    if not similar_profiles:
        return create_default_offer(candidate.experience)
    
    # Calculate base compensation
    avg_base = sum(r.get('base_salary', 0) for r in similar_profiles) / len(similar_profiles)
    avg_total = sum(r.get('total_compensation', 0) for r in similar_profiles) / len(similar_profiles)
    
    # Apply premiums
    total_premium = calculate_total_premium(candidate, role)
    company_multiplier = get_company_multiplier(company)
    location_multiplier = data.get("location_multipliers", {}).get(location, 1.0)
    
    # Calculate final offer
    base_salary = int(avg_base * (1 + total_premium) * company_multiplier * location_multiplier)
    total_comp = int(avg_total * (1 + total_premium) * company_multiplier * location_multiplier)
    
    # Component breakdown
    signing_bonus = int(base_salary * 0.15)
    annual_bonus = int(base_salary * 0.20)
    stock_grant = max(0, total_comp - base_salary - signing_bonus - annual_bonus)
    
    # Create offer ranges
    offer_range = {
        "base_salary_range": {
            "min": int(base_salary * 0.9),
            "max": int(base_salary * 1.1),
            "recommended": base_salary
        },
        "total_compensation_range": {
            "min": int(total_comp * 0.9),
            "max": int(total_comp * 1.15),
            "recommended": total_comp
        },
        "signing_bonus": signing_bonus,
        "annual_bonus": annual_bonus,
        "stock_grant": stock_grant,
        "components_breakdown": {
            "base_percentage": round((base_salary / total_comp) * 100, 1),
            "variable_percentage": round(((annual_bonus + stock_grant) / total_comp) * 100, 1),
            "bonus_percentage": round((signing_bonus / total_comp) * 100, 1)
        },
        "market_position": "Competitive" if 0.9 <= (total_comp / avg_total) <= 1.1 else "Above Market",
        "premium_factors": {
            "experience_premium": f"{candidate.experience} years",
            "company_tier": candidate.company_tier,
            "skills_match": len(candidate.skills),
            "total_premium_applied": f"{total_premium:.1%}"
        }
    }
    
    return offer_range

def get_experience_range(years: float) -> str:
    """Map experience years to ranges"""
    if years <= 2: return "0-2"
    elif years <= 5: return "2-5"
    elif years <= 8: return "5-8"
    elif years <= 12: return "8-12"
    else: return "12+"

def create_fallback_salary_data() -> Dict:
    """Create fallback salary data if file not found"""
    return {
        "market_data": [
            {"role": "Software Engineer", "location": "Bangalore", "experience_range": "0-2", "base_salary": 1500000, "total_compensation": 2000000},
            {"role": "Software Engineer II", "location": "Bangalore", "experience_range": "2-5", "base_salary": 2500000, "total_compensation": 3500000},
            {"role": "Senior Software Engineer", "location": "Bangalore", "experience_range": "5-8", "base_salary": 4000000, "total_compensation": 6000000},
        ],
        "location_multipliers": {"Bangalore": 1.0, "Mumbai": 1.1, "Delhi": 1.05, "Hyderabad": 0.9, "Chennai": 0.85}
    }

def create_default_offer(experience: float) -> Dict:
    """Create default offer when no market data available"""
    base = 1500000 + (experience * 300000)
    return {
        "base_salary_range": {"min": int(base * 0.9), "max": int(base * 1.1), "recommended": int(base)},
        "total_compensation_range": {"min": int(base * 1.3), "max": int(base * 1.6), "recommended": int(base * 1.4)},
        "market_position": "Estimated",
        "premium_factors": {"note": "Limited market data available"}
    }