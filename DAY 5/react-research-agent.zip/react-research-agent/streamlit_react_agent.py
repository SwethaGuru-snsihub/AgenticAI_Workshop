import streamlit as st
import os
import json
from typing import List, Dict, Any
from datetime import datetime
from dotenv import load_dotenv
import time

# LLM Integration
try:
    from langchain_google_genai import ChatGoogleGenerativeAI
    LLM_AVAILABLE = True
except ImportError:
    LLM_AVAILABLE = False
    st.error("⚠️ LangChain Google GenAI not installed. Run: pip install langchain-google-genai")

# Web Search Integration
try:
    from tavily import TavilyClient
    TAVILY_AVAILABLE = True
except ImportError:
    TAVILY_AVAILABLE = False
    st.error("⚠️ Tavily not installed. Run: pip install tavily-python")

# Load environment variables
load_dotenv()

# Page configuration
st.set_page_config(
    page_title="ReAct Research Agent",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #005bff 0%, #0000 100%);
        padding: 2rem;
        border-radius: 15px;
        text-align: center;
        color: white;
        margin-bottom: 2rem;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    }
    
    .react-step {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 4px solid #1e3c72;
        margin: 1rem 0;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    
    .success-box {
        background: #d4edda;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #28a745;
        margin: 1rem 0;
    }
    
    .info-box {
        background: #d1ecf1;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #17a2b8;
        margin: 1rem 0;
    }
    
    .warning-box {
        background: #fff3cd;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #ffc107;
        margin: 1rem 0;
    }
    
    .question-box {
        background: #e8f4f8;
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
        border-left: 3px solid #17a2b8;
        color:black;
    }
    
    .search-result {
        background: #f1f3f4;
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
        border-left: 3px solid #28a745;
        color: black;
    }
    
    .stProgress > div > div > div > div {
        background: linear-gradient(90deg, #1e3c72 0%, #2a5298 100%);
    }
</style>
""", unsafe_allow_html=True)

class StreamlitReActAgent:
    """
    ReAct Research Agent with Streamlit Interface
    """
    
    def __init__(self):
        """Initialize the ReAct agent"""
        
        # Check API keys
        self.gemini_api_key = os.getenv("GEMINI_API_KEY")
        self.tavily_api_key = os.getenv("TAVILY_API_KEY")
        
        if not self.gemini_api_key or not self.tavily_api_key:
            st.error("🔑 API keys missing! Please check your .env file.")
            st.stop()
        
        # Initialize LLM
        try:
            self.llm = ChatGoogleGenerativeAI(
                model="gemini-1.5-flash",
                google_api_key=self.gemini_api_key,
                temperature=0.7
            )
        except Exception as e:
            st.error(f"❌ Failed to initialize Gemini: {str(e)}")
            st.stop()
        
        # Initialize Tavily
        try:
            self.tavily_client = TavilyClient(api_key=self.tavily_api_key)
        except Exception as e:
            st.error(f"❌ Failed to initialize Tavily: {str(e)}")
            st.stop()
        
        # Initialize session state
        if 'research_data' not in st.session_state:
            st.session_state.research_data = {
                "topic": "",
                "questions": [],
                "search_results": {},
                "report": "",
                "step": 0
            }
    
    def generate_research_questions(self, topic: str, progress_bar, status_text) -> List[str]:
        """Generate research questions using LLM"""
        
        status_text.text("🧠 Planning Phase: Generating research questions...")
        progress_bar.progress(20)
        
        prompt = f"""
        You are an expert researcher. Given the topic "{topic}", generate exactly 6 comprehensive research questions that cover different aspects of this topic.
        
        Requirements:
        - Questions should be specific and answerable through web search
        - Cover different angles: causes, effects, current status, solutions, trends, future outlook
        - Each question should be clear and focused
        - Avoid yes/no questions; prefer "what", "how", "why" questions
        
        Topic: {topic}
        
        Please provide exactly 6 research questions, one per line, without numbering or bullet points:
        """
        
        try:
            with st.spinner("Generating questions with AI..."):
                response = self.llm.invoke(prompt)
                questions_text = response.content.strip()
                
                # Parse questions
                questions = [q.strip() for q in questions_text.split('\n') if q.strip()]
                
                # Ensure we have exactly 6 questions
                if len(questions) < 6:
                    questions.extend([
                        f"What are the latest developments in {topic}?",
                        f"What are the main challenges related to {topic}?",
                        f"How does {topic} impact society?",
                        f"What are future trends in {topic}?"
                    ])
                questions = questions[:6]
                
                progress_bar.progress(40)
                status_text.text("✅ Research questions generated!")
                
                return questions
                
        except Exception as e:
            st.error(f"❌ Failed to generate questions: {str(e)}")
            return []
    
    def search_web_for_question(self, question: str, question_num: int, total_questions: int) -> Dict[str, Any]:
        """Search web for a specific question"""
        
        try:
            # Perform web search
            search_response = self.tavily_client.search(
                query=question,
                search_depth="advanced",
                max_results=5,
                include_answer=True,
                include_raw_content=False
            )
            
            # Extract relevant information
            search_data = {
                "question": question,
                "answer": search_response.get("answer", ""),
                "results": []
            }
            
            # Process search results
            for result in search_response.get("results", []):
                result_data = {
                    "title": result.get("title", ""),
                    "url": result.get("url", ""),
                    "content": result.get("content", ""),
                    "score": result.get("score", 0)
                }
                search_data["results"].append(result_data)
            
            return search_data
            
        except Exception as e:
            st.error(f"❌ Search failed for question {question_num}: {str(e)}")
            return {
                "question": question,
                "answer": f"Search failed: {str(e)}",
                "results": []
            }
    
    def conduct_research(self, topic: str):
        """Complete research process with live updates"""
        
        # Initialize progress tracking
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        # Phase 1: Planning
        st.markdown("### 🧠 Phase 1: Planning (Reasoning)")
        with st.container():
            # st.markdown('<div class="react-step">', unsafe_allow_html=True)
            st.markdown("**ReAct Pattern - Reasoning Step:**")
            st.markdown("Using Large Language Model to generate strategic research questions...")
            st.markdown('</div>', unsafe_allow_html=True)
            
            questions = self.generate_research_questions(topic, progress_bar, status_text)
            
            if questions:
                st.markdown("**Generated Research Questions:**")
                for i, question in enumerate(questions, 1):
                    st.markdown(f'<div class="question-box">📋 <strong>Q{i}:</strong> {question}</div>', unsafe_allow_html=True)
                
                # Store in session state
                st.session_state.research_data["topic"] = topic
                st.session_state.research_data["questions"] = questions
        
        # Phase 2: Acting
        st.markdown("### 🔍 Phase 2: Acting (Web Search)")
        with st.container():
            # st.markdown('<div class="react-step">', unsafe_allow_html=True)
            st.markdown("**ReAct Pattern - Acting Step:**")
            st.markdown("Searching the web systematically for each research question...")
            st.markdown('</div>', unsafe_allow_html=True)
            
            search_results = {}
            
            for i, question in enumerate(questions, 1):
                # Update progress
                progress = 40 + (i * 40 / len(questions))
                progress_bar.progress(int(progress))
                status_text.text(f"🔍 Searching web for question {i}/{len(questions)}...")
                
                # Display current search
                with st.expander(f"🔍 Searching: {question}", expanded=True):
                    search_placeholder = st.empty()
                    search_placeholder.text("Searching web...")
                    
                    # Perform search
                    result = self.search_web_for_question(question, i, len(questions))
                    search_results[question] = result
                    
                    # Display results
                    search_placeholder.empty()
                    
                    if result["answer"]:
                        st.markdown("**AI Answer:**")
                        st.info(result["answer"])
                    
                    st.markdown("**Web Sources Found:**")
                    for j, source in enumerate(result["results"][:3], 1):
                        st.markdown(f'<div class="search-result">🔗 <strong>{j}.</strong> <a href="{source["url"]}" target="_blank">{source["title"]}</a><br><small>{source["content"][:200]}...</small></div>', unsafe_allow_html=True)
                
                # Small delay for better UX
                time.sleep(1)
            
            # Store search results
            st.session_state.research_data["search_results"] = search_results
            
            progress_bar.progress(100)
            status_text.text("✅ Web research completed!")
        
        return search_results
    
    def compile_report(self, progress_bar, status_text):
        """Compile structured research report"""
        
        status_text.text("📝 Compiling research report...")
        progress_bar.progress(20)
        
        topic = st.session_state.research_data["topic"]
        questions = st.session_state.research_data["questions"]
        search_results = st.session_state.research_data["search_results"]
        
        # Generate report using LLM
        report_prompt = f"""
        Create a comprehensive, professional research report based on the following data:
        
        Topic: {topic}
        
        Research Questions and Findings:
        """
        
        # Add each question and findings
        for question in questions:
            result = search_results.get(question, {})
            answer = result.get("answer", "No answer found")
            
            report_prompt += f"""
        
        Question: {question}
        Answer: {answer}
        
        Supporting Sources:
        """
            
            # Add source information
            for i, source in enumerate(result.get("results", [])[:3], 1):
                report_prompt += f"{i}. {source.get('title', 'Unknown Title')} - {source.get('url', '')}\n"
        
        report_prompt += f"""
        
        Please compile this into a well-structured research report with:
        1. Executive Summary
        2. Introduction
        3. Main findings organized by research questions
        4. Key insights and conclusions
        5. References
        
        Format it professionally with clear headings and structure.
        """
        
        try:
            progress_bar.progress(60)
            with st.spinner("AI is compiling your research report..."):
                response = self.llm.invoke(report_prompt)
                report = response.content
                
                # Add metadata header
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                header = f"""# Research Report: {topic}

**Generated by ReAct Research Agent**  
**Date:** {timestamp}  
**Questions Researched:** {len(questions)}  
**Sources Consulted:** {sum(len(r.get('results', [])) for r in search_results.values())}

---

"""
                
                final_report = header + report
                st.session_state.research_data["report"] = final_report
                
                progress_bar.progress(100)
                status_text.text("✅ Research report compiled!")
                
                return final_report
                
        except Exception as e:
            st.error(f"❌ Failed to compile report: {str(e)}")
            return self._create_basic_report()
    
    def _create_basic_report(self):
        """Create basic report as fallback"""
        topic = st.session_state.research_data["topic"]
        questions = st.session_state.research_data["questions"]
        search_results = st.session_state.research_data["search_results"]
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        report = f"""# Research Report: {topic}

**Generated by ReAct Research Agent**
**Date:** {timestamp}

## Executive Summary

This report presents comprehensive research findings on {topic} using the ReAct (Reasoning + Acting) pattern with AI-powered question generation and web search.

## Research Findings

"""
        
        for i, question in enumerate(questions, 1):
            result = search_results.get(question, {})
            answer = result.get("answer", "No answer found")
            
            report += f"""### {i}. {question}

{answer}

**Sources:**
"""
            
            for j, source in enumerate(result.get("results", [])[:3], 1):
                report += f"- [{source.get('title', 'Unknown')}]({source.get('url', '')})\n"
            
            report += "\n"
        
        report += f"""## Conclusion

This research on {topic} has provided insights across {len(questions)} key areas of investigation. The findings are based on current web sources and provide a comprehensive overview of the topic using the ReAct pattern of reasoning followed by systematic web search actions.

---
*Report generated using ReAct (Reasoning + Acting) pattern with LLM planning and web search execution.*
"""
        
        st.session_state.research_data["report"] = report
        return report

def main():
    """Main Streamlit application"""
    
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>🤖 ReAct Web Research Agent</h1>
        <p>AI-powered research agent that plans questions and searches the web systematically</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize agent
    if 'agent' not in st.session_state:
        with st.spinner("Initializing ReAct Research Agent..."):
            try:
                st.session_state.agent = StreamlitReActAgent()
                st.success("✅ Agent initialized successfully!")
            except Exception as e:
                st.error(f"❌ Failed to initialize agent: {str(e)}")
                st.stop()
    
    # Sidebar
    with st.sidebar:
        st.header("🛠️ ReAct Agent Control Panel")
        
        st.markdown("### 📋 Research Configuration")
        
        # Topic input
        topic = st.text_input(
            "🎯 Research Topic:",
            placeholder="e.g., Artificial Intelligence, Climate Change, Quantum Computing",
            help="Enter any topic you want to research comprehensively"
        )
        
        st.markdown("---")
        
        st.markdown("### 🧠 How ReAct Pattern Works:")
        st.markdown("""
        **1. 🧠 Reasoning (Planning)**
        - AI generates strategic research questions
        - Covers multiple aspects of the topic
        
        **2. 🔍 Acting (Web Search)**  
        - Systematically searches web for each question
        - Extracts relevant information and sources
        
        **3. 📝 Report Generation**
        - Compiles findings into structured report
        - Provides comprehensive analysis
        """)
        
        st.markdown("---")
        
        st.markdown("### 📊 Current Session:")
        if st.session_state.research_data["topic"]:
            st.info(f"**Topic:** {st.session_state.research_data['topic']}")
            st.info(f"**Questions:** {len(st.session_state.research_data['questions'])}")
            st.info(f"**Searches:** {len(st.session_state.research_data['search_results'])}")
        else:
            st.warning("No research conducted yet")
        
        # Clear session button
        if st.button("🗑️ Clear Session", type="secondary"):
            st.session_state.research_data = {
                "topic": "",
                "questions": [],
                "search_results": {},
                "report": "",
                "step": 0
            }
            st.success("Session cleared!")
            st.rerun()
    
    # Main content
    if topic:
        st.markdown(f"## 🎯 Research Topic: {topic}")
        
        # Start research button
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            start_research = st.button(
                "🚀 Start ReAct Research Process", 
                type="primary", 
                use_container_width=True
            )
        
        if start_research:
            # Conduct research
            st.markdown("## 🔄 ReAct Research Process")
            
            search_results = st.session_state.agent.conduct_research(topic)
            
            if search_results:
                # Compile report
                st.markdown("### 📝 Phase 3: Report Generation")
                with st.container():
                    # st.markdown('<div class="react-step">', unsafe_allow_html=True)
                    st.markdown("**ReAct Pattern - Report Compilation:**")
                    st.markdown("Synthesizing findings into comprehensive research report...")
                    st.markdown('</div>', unsafe_allow_html=True)
                    
                    progress_bar = st.progress(0)
                    status_text = st.empty()
                    
                    report = st.session_state.agent.compile_report(progress_bar, status_text)
                    
                    if report:
                        st.success("🎉 Research completed successfully!")
        
        # Display results if available
        if st.session_state.research_data["report"]:
            st.markdown("## 📄 Research Report")
            
            # Download button
            col1, col2, col3 = st.columns([1, 2, 1])
            with col2:
                st.download_button(
                    label="💾 Download Research Report",
                    data=st.session_state.research_data["report"],
                    file_name=f"research_report_{topic.replace(' ', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md",
                    mime="text/markdown",
                    type="secondary",
                    use_container_width=True
                )
            
            # Display report
            st.markdown(st.session_state.research_data["report"])
            
            # Research summary
            with st.expander("📊 Research Summary"):
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("Questions Generated", len(st.session_state.research_data["questions"]))
                
                with col2:
                    st.metric("Web Searches", len(st.session_state.research_data["search_results"]))
                
                with col3:
                    total_sources = sum(len(r.get("results", [])) for r in st.session_state.research_data["search_results"].values())
                    st.metric("Sources Found", total_sources)
                
                with col4:
                    st.metric("Report Length", f"{len(st.session_state.research_data['report'])} chars")
    
    else:
        # Welcome screen
        st.markdown("## 👋 Welcome to ReAct Research Agent")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("""
            ### 🎯 What is ReAct Pattern?
            
            **ReAct** = **Reasoning** + **Acting**
            
            This AI agent follows a systematic approach:
            1. **🧠 Reasons** about the topic to generate strategic questions
            2. **🔍 Acts** by searching the web for comprehensive answers
            3. **📝 Synthesizes** findings into a structured research report
            """)
        
        
        # Example topics
        st.markdown("### 🎯 Example Research Topics:")
        example_topics = [
            "Artificial Intelligence in Healthcare",
            "Climate Change Solutions",
            "Quantum Computing Applications",
            "Renewable Energy Technologies",
            "Space Exploration Missions",
            "Cybersecurity Trends"
        ]
        
        cols = st.columns(3)
        for i, example_topic in enumerate(example_topics):
            with cols[i % 3]:
                if st.button(example_topic, key=f"example_{i}"):
                    st.session_state.example_topic = example_topic
                    st.rerun()
        
        # Set example topic if clicked
        if 'example_topic' in st.session_state:
            st.info(f"💡 Try researching: {st.session_state.example_topic}")
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #666;">
        <p>🤖 Powered by LangChain + Google Gemini + Tavily • 🎓 ReAct Pattern Implementation • ⚡ Real-time Research</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()