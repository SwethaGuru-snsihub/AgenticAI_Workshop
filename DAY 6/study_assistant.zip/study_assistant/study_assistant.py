import PyPDF2
import os
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# Load environment variables
load_dotenv()

class StudyAssistant:
    def __init__(self):
        # Get API key from environment
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("Please set GEMINI_API_KEY in your .env file")
        
        # Initialize Gemini LLM
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=api_key,
            temperature=0.3
        )
        
        # Setup summarization chain
        summary_template = """
        You are an expert educational content analyzer. Summarize the following study material into clear, concise bullet points.

        STUDY MATERIAL:
        {content}

        INSTRUCTIONS:
        - Extract the most important concepts, definitions, and facts
        - Format as bullet points
        - Focus on information suitable for quiz questions
        - Aim for 8-15 key points

        OUTPUT FORMAT:
        Summary:
        • [Key point 1]
        • [Key point 2]
        • [Continue with more points...]
        """
        
        self.summary_prompt = PromptTemplate(
            input_variables=["content"],
            template=summary_template
        )
        
        self.summary_chain = LLMChain(
            llm=self.llm,
            prompt=self.summary_prompt
        )
        
        # Setup quiz generation chain
        quiz_template = """
        Create {num_questions} multiple-choice questions based on this summary.

        SUMMARY:
        {summary}

        REQUIREMENTS:
        - Each question has 4 options (a, b, c, d)
        - Only one correct answer per question
        - Test understanding, not just memorization
        - Cover different aspects of the material

        OUTPUT FORMAT:
        Quiz Questions:

        1. [Question]?
           a) [Option 1]
           b) [Option 2]
           c) [Option 3]
           d) [Option 4]
           Answer: [Letter]) [Correct answer]

        [Continue for all questions...]
        """
        
        self.quiz_prompt = PromptTemplate(
            input_variables=["summary", "num_questions"],
            template=quiz_template
        )
        
        self.quiz_chain = LLMChain(
            llm=self.llm,
            prompt=self.quiz_prompt
        )
    
    def extract_pdf_text(self, pdf_path):
        """Extract text from PDF file"""
        try:
            with open(pdf_path, "rb") as file:
                reader = PyPDF2.PdfReader(file)
                text = ""
                for page in reader.pages:
                    text += page.extract_text() + "\n"
                return text.strip()
        except Exception as e:
            raise Exception(f"Error reading PDF: {str(e)}")
    
    def summarize_content(self, content):
        """Summarize the study material"""
        try:
            summary = self.summary_chain.run(content=content)
            return summary
        except Exception as e:
            raise Exception(f"Error summarizing content: {str(e)}")
    
    def generate_quiz(self, summary, num_questions=8):
        """Generate quiz questions from summary"""
        try:
            quiz = self.quiz_chain.run(
                summary=summary,
                num_questions=num_questions
            )
            return quiz
        except Exception as e:
            raise Exception(f"Error generating quiz: {str(e)}")
    
    def process_pdf(self, pdf_path, num_questions=8):
        """Complete pipeline: PDF -> Summary -> Quiz"""
        print(f"Processing PDF: {pdf_path}")
        
        # Extract text
        print("1. Extracting text from PDF...")
        content = self.extract_pdf_text(pdf_path)
        
        if len(content.strip()) < 100:
            raise ValueError("PDF content too short")
        
        # Generate summary
        print("2. Generating summary...")
        summary = self.summarize_content(content)
        
        # Generate quiz
        print("3. Creating quiz questions...")
        quiz = self.generate_quiz(summary, num_questions)
        
        return {
            "summary": summary,
            "quiz": quiz,
            "content_length": len(content)
        }
    
    def process_text(self, content, num_questions=8):
        """Complete pipeline: Text -> Summary -> Quiz"""
        print("Processing text content...")
        
        if len(content.strip()) < 50:
            raise ValueError("Text content too short")
        
        # Generate summary
        print("1. Generating summary...")
        summary = self.summarize_content(content)
        
        # Generate quiz
        print("2. Creating quiz questions...")
        quiz = self.generate_quiz(summary, num_questions)
        
        return {
            "summary": summary,
            "quiz": quiz,
            "content_length": len(content)
        }

def main():
    """Main function to run the Study Assistant"""
    print("=" * 60)
    print("📚 STUDY ASSISTANT - QUIZ GENERATOR")
    print("=" * 60)
    
    try:
        # Initialize assistant
        assistant = StudyAssistant()
        print("✅ Assistant initialized successfully!")
        
        while True:
            print("\nChoose an option:")
            print("1. Process PDF file")
            print("2. Process text content")
            print("3. Exit")
            
            choice = input("\nEnter choice (1-3): ").strip()
            
            if choice == "1":
                # PDF processing
                pdf_path = input("Enter PDF file path: ").strip()
                
                if not os.path.exists(pdf_path):
                    print("❌ File not found!")
                    continue
                
                try:
                    num_questions = input("Number of questions (default 8): ").strip()
                    num_questions = int(num_questions) if num_questions else 8
                    
                    result = assistant.process_pdf(pdf_path, num_questions)
                    
                    print("\n" + "=" * 60)
                    print("📝 SUMMARY")
                    print("=" * 60)
                    print(result["summary"])
                    
                    print("\n" + "=" * 60)
                    print("❓ QUIZ QUESTIONS")
                    print("=" * 60)
                    print(result["quiz"])
                    
                    print(f"\n✅ Success! Processed {result['content_length']} characters")
                    
                except Exception as e:
                    print(f"❌ Error: {str(e)}")
            
            elif choice == "2":
                # Text processing
                print("Enter your study material (press Enter twice to finish):")
                lines = []
                while True:
                    line = input()
                    if line == "":
                        break
                    lines.append(line)
                
                content = "\n".join(lines)
                
                try:
                    num_questions = input("Number of questions (default 8): ").strip()
                    num_questions = int(num_questions) if num_questions else 8
                    
                    result = assistant.process_text(content, num_questions)
                    
                    print("\n" + "=" * 60)
                    print("📝 SUMMARY")
                    print("=" * 60)
                    print(result["summary"])
                    
                    print("\n" + "=" * 60)
                    print("❓ QUIZ QUESTIONS")
                    print("=" * 60)
                    print(result["quiz"])
                    
                    print(f"\n✅ Success! Processed {result['content_length']} characters")
                    
                except Exception as e:
                    print(f"❌ Error: {str(e)}")
            
            elif choice == "3":
                print("👋 Goodbye!")
                break
            
            else:
                print("❌ Invalid choice!")
    
    except Exception as e:
        print(f"❌ Failed to initialize: {str(e)}")
        print("Make sure you have set GEMINI_API_KEY in your .env file")

if __name__ == "__main__":
    main()
    
# run command - streamlit run streamlit_app.py