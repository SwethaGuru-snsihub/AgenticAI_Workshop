import streamlit as st
import PyPDF2
import os
import io
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# Load environment variables
load_dotenv()

# Page configuration
st.set_page_config(
    page_title="Study Assistant - Quiz Generator",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #131313  0%, #0040ff 100%);
        padding: 2rem;
        border-radius: 10px;
        text-align: center;
        color: white;
        margin-bottom: 2rem;
    }
    
    .feature-box {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 4px solid #667eea;
        margin: 1rem 0;
    }
    
    .success-box {
        background: #d4edda;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #28a745;
        margin: 1rem 0;
    }
    
    .error-box {
        background: #f8d7da;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #dc3545;
        margin: 1rem 0;
    }
    
    .stTextArea textarea {
        font-family: 'Courier New', monospace;
    }
</style>
""", unsafe_allow_html=True)

class StudyAssistant:
    def __init__(self):
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            st.error("⚠️ Please set GEMINI_API_KEY in your .env file")
            st.stop()
        
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=api_key,
            temperature=0.3
        )
        
        # Summary chain
        summary_template = """
        Analyze and summarize the following study material into clear bullet points.

        STUDY MATERIAL:
        {content}

        Create a concise summary with key concepts, definitions, and facts suitable for quiz questions.
        Format as bullet points starting with "Summary:"

        Summary:
        • [Key point 1]
        • [Key point 2]
        • [Continue with 8-15 key points...]
        """
        
        self.summary_chain = LLMChain(
            llm=self.llm,
            prompt=PromptTemplate(input_variables=["content"], template=summary_template)
        )
        
        # Quiz chain
        quiz_template = """
        Create {num_questions} multiple-choice questions based on this summary.

        SUMMARY:
        {summary}

        Format each question with 4 options (a, b, c, d) and provide the correct answer.

        Quiz Questions:

        1. [Question]?
           a) [Option 1]
           b) [Option 2] 
           c) [Option 3]
           d) [Option 4]
           Answer: [Letter]) [Correct answer]

        [Continue for all questions...]
        """
        
        self.quiz_chain = LLMChain(
            llm=self.llm,
            prompt=PromptTemplate(input_variables=["summary", "num_questions"], template=quiz_template)
        )
    
    def extract_pdf_text(self, pdf_file):
        try:
            reader = PyPDF2.PdfReader(pdf_file)
            text = ""
            for page in reader.pages:
                text += page.extract_text() + "\n"
            return text.strip()
        except Exception as e:
            raise Exception(f"Error reading PDF: {str(e)}")
    
    def process_content(self, content, num_questions):
        if len(content.strip()) < 50:
            raise ValueError("Content too short. Please provide at least 50 characters.")
        
        # Generate summary
        with st.spinner("🔍 Analyzing content and creating summary..."):
            summary = self.summary_chain.run(content=content)
        
        # Generate quiz
        with st.spinner("❓ Generating quiz questions..."):
            quiz = self.quiz_chain.run(summary=summary, num_questions=num_questions)
        
        return summary, quiz

def main():
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>📚 Study Assistant</h1>
        <h3>AI-Powered Quiz Generator</h3>
        <p>Transform your study materials into summaries and quiz questions instantly!</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize assistant
    if 'assistant' not in st.session_state:
        try:
            st.session_state.assistant = StudyAssistant()
        except Exception as e:
            st.error(f"Failed to initialize: {str(e)}")
            st.stop()
    
    # Sidebar
    with st.sidebar:
        st.header("⚙️ Settings")
        
        num_questions = st.slider(
            "Number of Questions",
            min_value=3,
            max_value=15,
            value=8,
            help="Choose how many quiz questions to generate"
        )
        
        st.markdown("---")
        
        st.markdown("""
        ### 💡 Tips for Best Results:
        - **PDF Files**: Ensure text is readable (not just images)
        - **Text Length**: Minimum 50 characters
        - **Content Type**: Educational material works best
        - **Question Count**: 5-10 questions optimal for most content
        """)
        
        st.markdown("---")
        
        st.markdown("""
        ### 🚀 How it Works:
        1. **Upload PDF** or **Enter Text**
        2. **AI analyzes** content using LangChain + Gemini
        3. **Get summary** with key bullet points  
        4. **Get quiz** with multiple-choice questions
        """)
    
    # Main content area
    tab1, tab2 = st.tabs(["📄 Upload PDF", "📝 Enter Text"])
    
    with tab1:
        st.markdown("""
        <div class="feature-box">
            <h3 style="color:black;">📄 PDF Processing</h3>
            <p style="color: black;">Upload any educational PDF file (textbooks, lecture notes, research papers) and get automatic summaries and quiz questions.</p>
        </div>
        """, unsafe_allow_html=True)
        
        uploaded_file = st.file_uploader(
            "Choose a PDF file",
            type="pdf",
            help="Upload a PDF containing study material"
        )
        
        if uploaded_file is not None:
            col1, col2 = st.columns([1, 3])
            
            with col1:
                process_pdf = st.button("🚀 Process PDF", type="primary", use_container_width=True)
            
            with col2:
                st.info(f"📄 File: {uploaded_file.name} ({uploaded_file.size} bytes)")
            
            if process_pdf:
                try:
                    # Extract text from PDF
                    with st.spinner("📖 Extracting text from PDF..."):
                        content = st.session_state.assistant.extract_pdf_text(uploaded_file)
                    
                    if len(content.strip()) < 100:
                        st.error("❌ PDF content too short or unreadable. Please try a different file.")
                    else:
                        # Process content
                        summary, quiz = st.session_state.assistant.process_content(content, num_questions)
                        
                        # Display results
                        st.success(f"✅ Successfully processed {len(content)} characters!")
                        
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.subheader("📝 Summary")
                            st.text_area("Generated Summary", summary, height=300, key="pdf_summary")
                        
                        with col2:
                            st.subheader("❓ Quiz Questions")
                            st.text_area("Generated Quiz", quiz, height=300, key="pdf_quiz")
                        
                        # Download buttons
                        col1, col2 = st.columns(2)
                        with col1:
                            st.download_button(
                                "💾 Download Summary",
                                summary,
                                file_name=f"summary_{uploaded_file.name}.txt",
                                mime="text/plain"
                            )
                        with col2:
                            st.download_button(
                                "💾 Download Quiz", 
                                quiz,
                                file_name=f"quiz_{uploaded_file.name}.txt",
                                mime="text/plain"
                            )
                
                except Exception as e:
                    st.error(f"❌ Error processing PDF: {str(e)}")
    
    with tab2:
        st.markdown("""
        <div class="feature-box">
            <h3 style="color: black;">📝 Text Processing</h3>
            <p style="color: black;">Paste or type your study material directly. Perfect for articles, notes, or any text content.</p>
        </div>
        """, unsafe_allow_html=True)
        
        text_content = st.text_area(
            "Enter your study material:",
            height=200,
            placeholder="Paste your study material here...\n\nExample: Machine learning is a subset of artificial intelligence that focuses on algorithms and statistical models...",
            help="Minimum 50 characters required"
        )
        
        col1, col2 = st.columns([1, 3])
        
        with col1:
            process_text = st.button("🚀 Process Text", type="primary", use_container_width=True)
        
        with col2:
            if text_content:
                st.info(f"📊 Character count: {len(text_content)}")
        
        if process_text and text_content:
            try:
                # Process text content
                summary, quiz = st.session_state.assistant.process_content(text_content, num_questions)
                
                # Display results
                st.success(f"✅ Successfully processed {len(text_content)} characters!")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.subheader("📝 Summary")
                    st.text_area("Generated Summary", summary, height=300, key="text_summary")
                
                with col2:
                    st.subheader("❓ Quiz Questions")  
                    st.text_area("Generated Quiz", quiz, height=300, key="text_quiz")
                
                # Download buttons
                col1, col2 = st.columns(2)
                with col1:
                    st.download_button(
                        "💾 Download Summary",
                        summary,
                        file_name="summary_text_content.txt",
                        mime="text/plain"
                    )
                with col2:
                    st.download_button(
                        "💾 Download Quiz",
                        quiz, 
                        file_name="quiz_text_content.txt",
                        mime="text/plain"
                    )
            
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")
        
        elif process_text and not text_content:
            st.warning("⚠️ Please enter some text content first!")
    
    # Example section
    with st.expander("📋 Try with Example Content"):
        example_content = """Machine Learning Fundamentals

Machine learning is a subset of artificial intelligence (AI) that focuses on algorithms and statistical models that enable computer systems to improve their performance on a specific task through experience without being explicitly programmed.

There are three main types of machine learning:

1. Supervised Learning: Uses labeled training data to learn a mapping function from input variables to output variables. Examples include classification and regression problems.

2. Unsupervised Learning: Finds hidden patterns in data without labeled examples. Common techniques include clustering and dimensionality reduction.

3. Reinforcement Learning: An agent learns to make decisions by performing actions in an environment and receiving rewards or penalties.

Key algorithms include linear regression, decision trees, neural networks, support vector machines, and k-means clustering. Machine learning applications span across various domains including image recognition, natural language processing, recommendation systems, and autonomous vehicles."""
        
        st.text_area("Example Study Material:", example_content, height=200, key="example_text")
        
        if st.button("🧪 Test with Example", use_container_width=True):
            try:
                summary, quiz = st.session_state.assistant.process_content(example_content, 5)
                
                st.success("✅ Example processed successfully!")
                
                col1, col2 = st.columns(2)
                with col1:
                    st.write("**Summary:**")
                    st.write(summary)
                with col2:
                    st.write("**Quiz:**")
                    st.write(quiz)
            
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #666;">
        <p>🤖 Powered by LangChain + Google Gemini • 📚 Built for Students • ⚡ Fast & Reliable</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()