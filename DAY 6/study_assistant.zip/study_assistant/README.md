Install Dependencies
# pip install -r requirements.txt

Setup Environment
# Create .env file 
# "GEMINI_API_KEY=your-actual-api-key-here"

run command 
# streamlit run streamlit_app.py