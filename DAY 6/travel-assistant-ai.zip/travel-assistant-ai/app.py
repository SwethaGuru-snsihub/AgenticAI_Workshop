import os
import streamlit as st
from dotenv import load_dotenv

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

from tools import get_weather, get_top_attractions

# Load environment variables
load_dotenv()

# Streamlit page config
st.set_page_config(page_title="🧳 Travel Assistant AI", page_icon="🌍")
st.title("🧳 Intelligent Travel Assistant")
st.markdown("Get **weather updates** and **top attractions** for any city 🌍")

# Input
city = st.text_input("Enter a city name:", placeholder="e.g. Tokyo")

if st.button("Get Travel Info"):
    if not city:
        st.warning("⚠️ Please enter a city name.")
    else:
        with st.spinner("Fetching info..."):

            try:
                # 1. Load LLM
                llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", temperature=0.3)

                # 2. Tools
                tools = [get_weather, get_top_attractions]

                # 3. Proper agent prompt
                prompt = ChatPromptTemplate.from_messages([
                    ("system", "You are a helpful travel assistant. Use the tools to answer user questions."),
                    ("human", "{input}"),
                    MessagesPlaceholder(variable_name="agent_scratchpad")  # ✅ This fixes the issue
                ])

                # 4. Create agent + executor
                agent = create_tool_calling_agent(llm=llm, tools=tools, prompt=prompt)
                agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

                # 5. Invoke
                result = agent_executor.invoke({"input": f"Tell me about {city}"})

                # 6. Show result
                st.success("✅ Here's what I found:")
                st.write(result["output"])

            except Exception as e:
                st.error(f"❌ Something went wrong: {str(e)}")
