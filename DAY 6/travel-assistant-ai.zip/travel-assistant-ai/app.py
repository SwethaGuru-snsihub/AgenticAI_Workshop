import os
import streamlit as st
from dotenv import load_dotenv

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

from tools import get_weather, get_top_attractions

# Load environment variables
load_dotenv()

st.set_page_config(page_title="Travel Assistant AI", page_icon="🌍")
st.title("Travel Assistant")
st.markdown("Get **weather updates** and **top attractions** for any city 🌍")

# Input
city = st.text_input("Enter a city name:", placeholder="e.g. Tokyo, Coimbatore...")

if st.button("Get Travel Info"):
    if not city:
        st.warning("⚠️ Please enter a city name.")
    else:
        with st.spinner("Fetching info..."):

            try:
                # 1. Load LLM
                llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", temperature=0.3)

                # 2. Tools
                tools = [get_weather, get_top_attractions]

                # 3. Proper agent prompt
                prompt = ChatPromptTemplate.from_messages([
                    ("system", "You are a helpful travel assistant. Whenever a user asks about a city, ALWAYS provide BOTH the current weather and the top tourist attractions for that city using the available tools. For each attraction, provide a short, informative description and format the list of attractions as markdown bullet points, with the attraction name in bold, followed by its description. Weather and attractions must be clearly separated."),
                    ("human", "{input}"),
                    MessagesPlaceholder(variable_name="agent_scratchpad")
                ])

                # 4. Create agent + executor
                agent = create_tool_calling_agent(llm=llm, tools=tools, prompt=prompt)
                agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

                # 5. Invoke
                result = agent_executor.invoke({"input": f"Tell me about {city}"})

                # 6. Show result
                st.success("✅ Here's what I found:")
                output = result["output"]

                if 'Weather in' in output and 'Top tourist attractions' in output:
                    weather_part = output.split('Top tourist attractions')[0].strip()
                    attractions_part = 'Top tourist attractions' + output.split('Top tourist attractions',1)[1]
                    st.markdown(f"### Weather\n{weather_part}")
                    st.markdown(f"### Attractions")
                    st.markdown(attractions_part)
                else:
                    st.write(output)

            except Exception as e:
                st.error(f"❌ Something went wrong: {str(e)}")
