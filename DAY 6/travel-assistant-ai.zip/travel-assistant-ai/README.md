# 🧳 Travel Assistant AI
## Setup Instructions

### 1. Clone this repository / Download zip
cd travel-assistant-ai

### 2. Install dependencies
pip install -r requirements.txt

### 3. Set up API keys
Create a `.env` file in the project directory with the following:

WEATHER_API_KEY=your_weatherapi_com_key
GOOGLE_API_KEY=your_gemini_api_key

- Get a free WeatherAPI key from [weatherapi.com](https://www.weatherapi.com/)
- Get a Gemini API key from [Google AI Studio](https://makersuite.google.com/app/apikey)

### 4. Run the app
streamlit run app.py


