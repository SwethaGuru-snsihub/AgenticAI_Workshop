# tools.py

import os
import requests
from dotenv import load_dotenv
from langchain.tools import tool
from langchain_community.tools import DuckDuckGoSearchResults

load_dotenv()
WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")

# Weather Tool
@tool
def get_weather(city: str) -> str:
    """Fetches current weather for a city using WeatherAPI."""
    try:
        url = f"http://api.weatherapi.com/v1/current.json?key={WEATHER_API_KEY}&q={city}"
        response = requests.get(url)
        data = response.json()
        if 'error' in data:
            return f"Error: {data['error']['message']}"
        condition = data['current']['condition']['text']
        temp = data['current']['temp_c']
        return f"🌤️ Weather in {city}: {condition}, {temp}°C"
    except Exception as e:
        return f"Weather API error: {str(e)}"

# Tourist Attraction Tool
search = DuckDuckGoSearchResults()

@tool
def get_top_attractions(city: str) -> str:
    """Returns top tourist attractions in a city using DuckDuckGo."""
    query = f"Top tourist attractions in {city}"
    return search.run(query)
