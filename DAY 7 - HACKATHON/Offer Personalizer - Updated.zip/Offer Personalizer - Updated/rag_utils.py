from langchain.vectorstores import FAISS
from langchain_google_genai import GoogleGenerativeAIEmbeddings, ChatGoogleGenerativeAI
from langchain.chains import RetrievalQA
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.docstore.document import Document
from langchain.prompts import PromptTemplate
from langchain.agents import Tool, initialize_agent, AgentType
from langchain.memory import ConversationBufferMemory
from offer_logic import CandidateProfile
import json
import os
from dotenv import load_dotenv
from typing import Dict, List
import requests

load_dotenv()

class OfferPersonalizationAgent:
    """Intelligent agent for offer personalization with RAG capabilities"""
    
    def __init__(self):
        self.api_key = os.getenv("GOOGLE_API_KEY")
        if not self.api_key:
            raise ValueError("GOOGLE_API_KEY not found in environment variables")
        
        self.embeddings = GoogleGenerativeAIEmbeddings(
            model="models/embedding-001",
            google_api_key=self.api_key
        )
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=self.api_key,
            temperature=0.3
        )
        self.vectorstore = None
        self.agent = None
        self.memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
        self._initialize_agent()
    
    def _load_enhanced_market_data(self) -> List[Document]:
        """Load comprehensive market data for RAG"""
        try:
            with open("salary_data.json") as f:
                data = json.load(f)
        except FileNotFoundError:
            data = self._create_enhanced_market_data()
        
        documents = []
        
        # Process market data
        for record in data.get("market_data", []):
            content = self._format_salary_record(record)
            metadata = {
                "role": record.get("role", ""),
                "company": record.get("company", ""),
                "location": record.get("location", ""),
                "experience": record.get("experience_range", ""),
                "type": "salary_data"
            }
            documents.append(Document(page_content=content, metadata=metadata))
        
        # Add market insights
        for insight in data.get("market_insights", []):
            documents.append(Document(
                page_content=insight["content"],
                metadata={"type": "market_insight", "category": insight.get("category", "")}
            ))
        
        # Add company information
        for company, info in data.get("company_info", {}).items():
            content = f"Company: {company}. {info['description']} Culture: {info['culture']} Benefits: {', '.join(info['benefits'])}"
            documents.append(Document(
                page_content=content,
                metadata={"type": "company_info", "company": company}
            ))
        
        return documents
    
    def _format_salary_record(self, record: Dict) -> str:
        """Format salary record for better retrieval"""
        base_lpa = record.get("base_salary", 0) / 100000
        total_lpa = record.get("total_compensation", 0) / 100000
        
        return f"""
        Role: {record.get('role', 'N/A')} at {record.get('company', 'N/A')}
        Location: {record.get('location', 'N/A')}
        Experience: {record.get('experience_range', 'N/A')} years
        Base Salary: ₹{base_lpa:.1f} LPA
        Total Compensation: ₹{total_lpa:.1f} LPA
        Stock Component: ₹{(record.get('stock_grant', 0))/100000:.1f} LPA
        Bonus: ₹{(record.get('annual_bonus', 0))/100000:.1f} LPA
        Market Tier: {record.get('market_tier', 'Standard')}
        """
    
    def _build_vectorstore(self):
        """Build FAISS vectorstore from market data"""
        documents = self._load_enhanced_market_data()
        
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=800,
            chunk_overlap=100,
            length_function=len
        )
        
        chunks = text_splitter.split_documents(documents)
        self.vectorstore = FAISS.from_documents(chunks, self.embeddings)
    
    def _salary_lookup_tool(self, query: str) -> str:
        """Tool for salary data lookup"""
        if not self.vectorstore:
            self._build_vectorstore()
        
        retriever = self.vectorstore.as_retriever(search_kwargs={"k": 5})
        docs = retriever.get_relevant_documents(query)
        
        results = []
        for doc in docs:
            results.append(f"Data: {doc.page_content}")
        
        return "\n\n".join(results)
    
    def _market_analysis_tool(self, query: str) -> str:
        """Tool for market trend analysis"""
        market_trends = {
            "2024": {
                "growth_rate": "8-12%",
                "hot_skills": ["AI/ML", "Cloud Native", "System Design", "Kubernetes"],
                "market_condition": "Candidate favorable for senior roles"
            },
            "hiring_trends": {
                "remote_premium": "5-10%",
                "tier1_companies": "Selective hiring, 20-30% premium",
                "startups": "Aggressive hiring, equity-heavy packages"
            }
        }
        
        return f"Current Market Analysis: {json.dumps(market_trends, indent=2)}"
    
    def _compensation_benchmarking_tool(self, query: str) -> str:
        """Tool for detailed compensation benchmarking"""
        if not self.vectorstore:
            self._build_vectorstore()
        
        # Extract role and location from query
        retriever = self.vectorstore.as_retriever(
            search_type="similarity_score_threshold",
            search_kwargs={"score_threshold": 0.5, "k": 10}
        )
        
        relevant_docs = retriever.get_relevant_documents(query)
        
        benchmark_data = []
        for doc in relevant_docs:
            if "Total Compensation" in doc.page_content:
                benchmark_data.append(doc.page_content)
        
        return f"Compensation Benchmarks:\n" + "\n---\n".join(benchmark_data[:5])
    
    def _initialize_agent(self):
        """Initialize the agent with tools"""
        tools = [
            Tool(
                name="SalaryLookup",
                func=self._salary_lookup_tool,
                description="Look up salary data for specific roles, companies, locations, and experience levels"
            ),
            Tool(
                name="MarketAnalysis",
                func=self._market_analysis_tool,
                description="Get current market trends and hiring insights"
            ),
            Tool(
                name="CompensationBenchmarking",
                func=self._compensation_benchmarking_tool,
                description="Get detailed compensation benchmarking data for offer comparison"
            )
        ]
        
        self.agent = initialize_agent(
            tools=tools,
            llm=self.llm,
            agent=AgentType.CONVERSATIONAL_REACT_DESCRIPTION,
            memory=self.memory,
            verbose=True,
            max_iterations=3
        )
    
    def generate_offer_justification(self, candidate: CandidateProfile, offer: Dict) -> str:
        """Generate comprehensive offer justification using agent"""
        
        prompt = f"""
        As an expert compensation analyst, provide a detailed justification for this offer:
        
        CANDIDATE PROFILE:
        - Name: {candidate.name}
        - Experience: {candidate.experience} years
        - Current Role: {candidate.current_role}
        - Current Company: {candidate.current_company} (Tier: {candidate.company_tier})
        - Location: {candidate.location}
        - Skills: {', '.join(candidate.skills)}
        - Education: {', '.join(candidate.education)}
        
        PROPOSED OFFER:
        - Base Salary: ₹{offer.get('base_salary_range', {}).get('recommended', 0)/100000:.1f} LPA
        - Total Compensation: ₹{offer.get('total_compensation_range', {}).get('recommended', 0)/100000:.1f} LPA
        - Market Position: {offer.get('market_position', 'N/A')}
        
        Please provide:
        1. Market benchmark analysis comparing this offer to similar profiles
        2. Justification based on candidate's experience and skills
        3. Company tier and location adjustments
        4. Competitive positioning against market standards
        5. Recommendations for negotiation points
        
        Use the available tools to gather relevant market data and provide a comprehensive analysis.
        """
        
        try:
            response = self.agent.run(prompt)
            return response
        except Exception as e:
            return f"Error generating justification: {str(e)}\n\nFallback analysis: This offer appears competitive based on the candidate's {candidate.experience} years of experience in {candidate.location}."
    
    def generate_scorecard(self, candidate: CandidateProfile, offer: Dict) -> Dict:
        """Generate candidate strength and market alignment scorecard"""
        
        scorecard = {
            "candidate_strength": {
                "experience_score": min(candidate.experience * 10, 100),
                "skills_score": min(len(candidate.skills) * 8, 100),
                "company_tier_score": {
                    "tier1": 95, "tier2": 75, "startup": 60, "service": 45
                }.get(candidate.company_tier, 50),
                "education_score": 85 if any('iit' in edu.lower() for edu in candidate.education) else 70
            },
            "market_alignment": {
                "salary_percentile": self._calculate_percentile(offer),
                "market_competitiveness": offer.get('market_position', 'Competitive'),
                "premium_applied": offer.get('premium_factors', {}).get('total_premium_applied', '0%')
            },
            "offer_components": {
                "base_salary_strength": "Strong" if offer.get('components_breakdown', {}).get('base_percentage', 0) > 60 else "Moderate",
                "variable_comp_ratio": f"{offer.get('components_breakdown', {}).get('variable_percentage', 0)}%",
                "total_package_rating": "Competitive"
            }
        }
        
        # Calculate overall score
        strength_scores = list(scorecard["candidate_strength"].values())
        avg_strength = sum([s for s in strength_scores if isinstance(s, (int, float))]) / len([s for s in strength_scores if isinstance(s, (int, float))])
        scorecard["overall_score"] = round(avg_strength, 1)
        
        return scorecard
    
    def _calculate_percentile(self, offer: Dict) -> str:
        """Calculate offer percentile in market"""
        # Simplified percentile calculation
        recommended = offer.get('total_compensation_range', {}).get('recommended', 0)
        market_min = offer.get('total_compensation_range', {}).get('min', 0)
        market_max = offer.get('total_compensation_range', {}).get('max', 0)
        
        if market_max > market_min:
            percentile = ((recommended - market_min) / (market_max - market_min)) * 100
            if percentile >= 75:
                return "75th+ percentile"
            elif percentile >= 50:
                return "50-75th percentile"
            else:
                return "Below 50th percentile"
        
        return "Market aligned"
    
    def _create_enhanced_market_data(self) -> Dict:
        """Create enhanced market data based on current trends"""
        return {
            "market_data": [
                # Google data
                {"role": "Software Engineer", "company": "Google", "location": "Bangalore", "experience_range": "0-2", 
                 "base_salary": 1800000, "total_compensation": 2300000, "stock_grant": 300000, "annual_bonus": 200000, "market_tier": "Tier1"},
                {"role": "Software Engineer II", "company": "Google", "location": "Bangalore", "experience_range": "2-5", 
                 "base_salary": 3200000, "total_compensation": 4500000, "stock_grant": 800000, "annual_bonus": 500000, "market_tier": "Tier1"},
                {"role": "Senior Software Engineer", "company": "Google", "location": "Bangalore", "experience_range": "5-8", 
                 "base_salary": 5500000, "total_compensation": 8500000, "stock_grant": 2000000, "annual_bonus": 1000000, "market_tier": "Tier1"},
                
                # Microsoft data  
                {"role": "Software Engineer", "company": "Microsoft", "location": "Bangalore", "experience_range": "0-2", 
                 "base_salary": 1700000, "total_compensation": 2200000, "stock_grant": 300000, "annual_bonus": 200000, "market_tier": "Tier1"},
                {"role": "Software Engineer II", "company": "Microsoft", "location": "Bangalore", "experience_range": "2-5", 
                 "base_salary": 3000000, "total_compensation": 4200000, "stock_grant": 700000, "annual_bonus": 500000, "market_tier": "Tier1"},
                {"role": "Senior Software Engineer", "company": "Microsoft", "location": "Bangalore", "experience_range": "5-8", 
                 "base_salary": 5200000, "total_compensation": 8000000, "stock_grant": 1800000, "annual_bonus": 1000000, "market_tier": "Tier1"},
                
                # Amazon data
                {"role": "Software Engineer", "company": "Amazon", "location": "Bangalore", "experience_range": "0-2", 
                 "base_salary": 1600000, "total_compensation": 2100000, "stock_grant": 300000, "annual_bonus": 200000, "market_tier": "Tier1"},
                {"role": "Software Engineer II", "company": "Amazon", "location": "Bangalore", "experience_range": "2-5", 
                 "base_salary": 2800000, "total_compensation": 4000000, "stock_grant": 700000, "annual_bonus": 500000, "market_tier": "Tier1"},
                
                # Startup data
                {"role": "Software Engineer", "company": "Razorpay", "location": "Bangalore", "experience_range": "2-5", 
                 "base_salary": 2200000, "total_compensation": 3000000, "stock_grant": 500000, "annual_bonus": 300000, "market_tier": "Tier2"},
                {"role": "Senior Software Engineer", "company": "Flipkart", "location": "Bangalore", "experience_range": "5-8", 
                 "base_salary": 3800000, "total_compensation": 5500000, "stock_grant": 1000000, "annual_bonus": 700000, "market_tier": "Tier2"},
                
                # Service companies
                {"role": "Software Engineer", "company": "TCS", "location": "Bangalore", "experience_range": "0-2", 
                 "base_salary": 800000, "total_compensation": 1000000, "stock_grant": 0, "annual_bonus": 200000, "market_tier": "Service"},
                {"role": "Software Engineer II", "company": "Infosys", "location": "Bangalore", "experience_range": "2-5", 
                 "base_salary": 1400000, "total_compensation": 1800000, "stock_grant": 100000, "annual_bonus": 300000, "market_tier": "Service"},
            ],
            "market_insights": [
                {
                    "category": "hiring_trends",
                    "content": "Tech hiring in 2024 shows 15% growth in senior roles (5+ years) with AI/ML skills commanding 20-25% premium. Remote work policies vary by company tier."
                },
                {
                    "category": "compensation_trends", 
                    "content": "Stock grants now comprise 25-40% of total compensation at tier-1 companies. Base salary growth is 8-12% YoY across all experience levels."
                },
                {
                    "category": "skill_premiums",
                    "content": "High-demand skills: System Design (+15%), Machine Learning (+20%), Cloud Architecture (+12%), Kubernetes (+10%). Full-stack capabilities expected baseline."
                }
            ],
            "company_info": {
                "Google": {
                    "description": "Leading technology company with focus on AI, cloud, and consumer products.",
                    "culture": "Innovation-driven, data-focused, collaborative",
                    "benefits": ["Health insurance", "Stock options", "Learning budget", "Flexible work", "Wellness programs"]
                },
                "Microsoft": {
                    "description": "Global technology leader in cloud computing, productivity software, and enterprise solutions.",
                    "culture": "Growth mindset, inclusive, customer-obsessed", 
                    "benefits": ["Comprehensive health", "Stock purchase plan", "Professional development", "Hybrid work"]
                },
                "Amazon": {
                    "description": "E-commerce and cloud computing giant with diverse business portfolio.",
                    "culture": "Customer obsession, ownership, high performance",
                    "benefits": ["Medical coverage", "Stock units", "Career advancement", "Innovation time"]
                }
            },
            "location_multipliers": {
                "Bangalore": 1.0,
                "Mumbai": 1.1, 
                "Delhi": 1.05,
                "Hyderabad": 0.9,
                "Chennai": 0.85,
                "Pune": 0.88
            }
        }


# Convenience function for backward compatibility
def get_market_justification(candidate: CandidateProfile, offer: Dict = None) -> str:
    """Generate market justification using the agent"""
    agent = OfferPersonalizationAgent()
    
    if offer is None:
        # Generate a basic offer first
        from offer_logic import generate_market_aligned_offer
        offer = generate_market_aligned_offer(candidate, candidate.current_role or "Software Engineer", 
                                            candidate.current_company or "Tech Company", 
                                            candidate.location or "Bangalore")
    
    return agent.generate_offer_justification(candidate, offer)

def get_candidate_scorecard(candidate: CandidateProfile, offer: Dict) -> Dict:
    """Generate candidate scorecard"""
    agent = OfferPersonalizationAgent()
    return agent.generate_scorecard(candidate, offer)