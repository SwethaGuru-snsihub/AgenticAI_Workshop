import os
from typing import Dict, Optional
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from dotenv import load_dotenv

# Ensure db_utils is initialized before using it
from utils.db_utils import candidate_db, initialize_dbs
from utils.data_loader import load_market_data, load_candidate_data

load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if not GEMINI_API_KEY:
    raise ValueError("GEMINI_API_KEY not found in .env file. Please set it.")

class CandidatePositioningAgent:
    def __init__(self):
        # We assume candidate_db is initialized globally in app.py or through initialize_dbs call
        if candidate_db is None:
            # Fallback for direct testing, normally initialized in main app
            print("WARNING: CandidateDB not initialized, attempting to initialize now.")
            initialize_dbs(load_market_data(), load_candidate_data())
        self.candidate_db = candidate_db
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            temperature=0.2,
            google_api_key=GEMINI_API_KEY
        )

        self.prompt_template = PromptTemplate(
            input_variables=["candidate_profile_json", "job_description"],
            template="""
            You are an expert HR recruitment specialist. Your task is to analyze a candidate's profile
            in the context of a specific job description and highlight their strengths and unique value proposition.

            Candidate Profile (JSON format):
            {candidate_profile_json}

            Job Description:
            {job_description}

            Based on the above, provide a comprehensive summary including:
            - Key strengths relevant to the job.
            - Years of experience and how they align with the role.
            - Specific skills that make them a strong fit.
            - Any unique contributions or achievements implied by their profile.
            - Their current location and relocation flexibility.
            - A "value score" or overall assessment of their fit (e.g., "High Fit", "Good Fit", "Moderate Fit").
            - Their last drawn salary (if available) and desired salary, and any potential salary expectations.

            Structure the output clearly.
            """
        )
        self.chain = LLMChain(llm=self.llm, prompt=self.prompt_template)

    def analyze_candidate_profile(self, candidate_id: str, job_description: str) -> str:
        """
        Analyzes a candidate's profile against a job description.
        Retrieves profile from mock DB and uses LLM for analysis.
        """
        candidate_profile = self.candidate_db.find_one(candidate_id)
        if not candidate_profile:
            return f"Candidate with ID '{candidate_id}' not found in the database."

        candidate_profile_json_str = json.dumps(candidate_profile, indent=2)

        response = self.chain.run(
            candidate_profile_json=candidate_profile_json_str,
            job_description=job_description
        )
        return response

if __name__ == '__main__':
    # Initialize DBs for testing the agent directly
    initialize_dbs(load_market_data(), load_candidate_data())

    agent = CandidatePositioningAgent()
    candidate_id_to_test = "cand_001"
    sample_job_description = """
    We are looking for a skilled Software Engineer with 3-5 years of experience in Python and Java.
    Experience with AWS and microservices is a strong plus. The candidate should be proficient
    in database technologies (SQL) and have a strong problem-solving aptitude.
    Location: Bengaluru, India.
    """
    analysis = agent.analyze_candidate_profile(candidate_id_to_test, sample_job_description)
    print("\nCandidate Analysis:\n", analysis)

    analysis_no_candidate = agent.analyze_candidate_profile("cand_999", sample_job_description)
    print("\nCandidate Analysis (No Candidate):\n", analysis_no_candidate)