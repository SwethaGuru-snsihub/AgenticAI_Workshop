import os
from typing import Dict, Optional
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from dotenv import load_dotenv

load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if not GEMINI_API_KEY:
    raise ValueError("GEMINI_API_KEY not found in .env file. Please set it.")

class OfferJustificationAgent:
    def __init__(self):
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            temperature=0.3,
            google_api_key=GEMINI_API_KEY
        )

        self.prompt_template = PromptTemplate(
            input_variables=["generated_offer", "candidate_profile_summary", "market_benchmarks", "job_description", "company_specific_guidelines"],
            template="""
            You are an AI assistant tasked with providing clear and transparent justification for a proposed compensation offer.

            Based on the following information:
            - Proposed Compensation Offer:
            {generated_offer}

            - Candidate Profile Summary:
            {candidate_profile_summary}

            - Market Benchmarks:
            {market_benchmarks}

            - Job Description:
            {job_description}

            - Company Specific Compensation Guidelines:
            {company_specific_guidelines}

            Provide a detailed justification for each component of the compensation package. Explain:
            - How the Base Salary aligns with market trends, the candidate's experience, and their desired salary.
            - The rationale behind the Performance Bonus percentage.
            - Why the specific Equity/Stock Options are proposed.
            - The value and relevance of the Additional Benefits.
            - Any location-based considerations.

            The justification should be transparent, data-driven, and persuasive for both the candidate and internal stakeholders.
            Start with an opening statement like "The proposed compensation package is carefully crafted to reflect..."
            """
        )
        self.chain = LLMChain(llm=self.llm, prompt=self.prompt_template)

    def justify_offer(
        self,
        generated_offer: str,
        candidate_profile_summary: str,
        market_benchmarks: str,
        job_description: str,
        company_specific_guidelines: str = "Standard company benefits apply. Performance bonus up to 20% of base. Equity grant for senior roles over 4 years."
    ) -> str:
        """
        Generates detailed justification for a compensation offer.
        """
        response = self.chain.run(
            generated_offer=generated_offer,
            candidate_profile_summary=candidate_profile_summary,
            market_benchmarks=market_benchmarks,
            job_description=job_description,
            company_specific_guidelines=company_specific_guidelines
        )
        return response

if __name__ == '__main__':
    agent = OfferJustificationAgent()

    sample_generated_offer = """
    **Base Salary (Annual):** 22 LPA (INR)
    **Performance Bonus:** 18% of Base Salary
    **Equity/Stock Options:** $25,000 USD (vested over 4 years)
    **Additional Benefits:** Health Insurance, PF, Gratuity, Learning Stipend, Wellness Program.
    **Location-based Adjustments:** Offer is specific to Bengaluru market.
    """
    sample_candidate_summary = """
    Arjun Kumar is a highly skilled Software Engineer with 4 years of experience, particularly strong in Python, Java, React, and AWS.
    He has a B.Tech in Computer Science and has worked at notable companies like Tech Solutions Inc.
    His last drawn salary was 18 LPA, and his desired salary is 22 LPA. He is currently based in Bengaluru and is not looking to relocate.
    Overall assessment: High Fit.
    """
    sample_market_benchmarks = """
    - Median Base Salary Range: 20 LPA - 25 LPA (INR) for Mid-level Software Engineer in Bengaluru, India.
    - Typical Performance Bonus Percentage: 15-20%.
    - Equity/Stock Options Range: $10,000 - $30,000 USD over 4 years.
    - Common Additional Benefits: Health Insurance, PF, Gratuity, Learning Stipend.
    """
    sample_job_description = """
    We are hiring a Mid-level Software Engineer for our Bengaluru office. Requires strong Python/Java skills and experience with cloud platforms like AWS.
    """
    sample_company_guidelines = "Standard company benefits apply. Performance bonus up to 20% of base. Equity grant for senior roles over 4 years."


    justification = agent.justify_offer(
        sample_generated_offer,
        sample_candidate_summary,
        sample_market_benchmarks,
        sample_job_description,
        sample_company_guidelines
    )
    print("\nOffer Justification:\n", justification)