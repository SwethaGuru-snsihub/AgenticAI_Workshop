import os
from typing import Dict, List, Optional
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from dotenv import load_dotenv
import json

# Ensure db_utils is initialized before using it
from utils.db_utils import market_vector_db, initialize_dbs
from utils.data_loader import load_market_data, load_candidate_data

load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if not GEMINI_API_KEY:
    raise ValueError("GEMINI_API_KEY not found in .env file. Please set it.")

class MarketBenchmarkRetrieverAgent:
    def __init__(self):
        # We assume market_vector_db is initialized globally in app.py or through initialize_dbs call
        if market_vector_db is None:
            # Fallback for direct testing, normally initialized in main app
            print("WARNING: MarketVectorDB not initialized, attempting to initialize now.")
            initialize_dbs(load_market_data(), load_candidate_data())
        self.market_vector_db = market_vector_db
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            temperature=0.1,
            google_api_key=GEMINI_API_KEY
        )

        self.prompt_template = PromptTemplate(
            input_variables=["job_title", "experience_level", "location", "industry", "market_data_results"],
            template="""
            You are an expert HR analyst. Your task is to analyze market salary benchmark data and summarize the relevant compensation details.

            Given the following job details:
            - Job Title: {job_title}
            - Experience Level: {experience_level}
            - Location: {location}
            - Industry: {industry}

            And the following retrieved market data (use this as your primary source of truth):
            {market_data_results}

            Provide a concise summary of the market benchmarks including:
            - Median Base Salary Range (in relevant currency, e.g., INR)
            - Typical Performance Bonus Percentage
            - Equity/Stock Options Range (in USD)
            - Common Additional Benefits
            - A note on location-based adjustments if any specific trends are observed.

            If no relevant market data is found, state that clearly.
            Structure the output as clear bullet points.
            """
        )
        self.chain = LLMChain(llm=self.llm, prompt=self.prompt_template)

    def retrieve_benchmarks(self, job_title: str, experience_level: str, location: str, industry: str) -> str:
        """
        Retrieves market salary benchmarks based on job details.
        Uses FAISS to find relevant data and then LLM to summarize.
        """
        query = f"{job_title}, {experience_level}, {location}, {industry}"
        retrieved_docs = self.market_vector_db.search(query, k=3) # Retrieve top 3 relevant documents

        if not retrieved_docs:
            return "No relevant market data found for the given criteria."

        market_data_str = "\n".join([json.dumps(doc.metadata, indent=2) for doc in retrieved_docs])

        # Use LLM to summarize the retrieved data
        response = self.chain.run(
            job_title=job_title,
            experience_level=experience_level,
            location=location,
            industry=industry,
            market_data_results=market_data_str
        )
        return response

if __name__ == '__main__':
    # Initialize DBs for testing the agent directly
    initialize_dbs(load_market_data(), load_candidate_data())

    agent = MarketBenchmarkRetrieverAgent()
    job_details = {
        "job_title": "Software Engineer",
        "experience_level": "Mid-level",
        "location": "Bengaluru, India",
        "industry": "Software"
    }
    benchmarks = agent.retrieve_benchmarks(**job_details)
    print("\nMarket Benchmarks:\n", benchmarks)

    job_details_no_data = {
        "job_title": "Quantum Computing Engineer",
        "experience_level": "Senior",
        "location": "Remote, Global",
        "industry": "Deep Tech"
    }
    benchmarks_no_data = agent.retrieve_benchmarks(**job_details_no_data)
    print("\nMarket Benchmarks (No Data):\n", benchmarks_no_data)