import os
from dotenv import load_dotenv

# Load environment variables first
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if not GEMINI_API_KEY:
    raise ValueError("GEMINI_API_KEY not found in .env file. Please set it.")

import streamlit as st

# Set page config - must be the first Streamlit command
st.set_page_config(page_title="Intelligent Offer Personalizer", layout="wide")

# Import utilities and agents
from utils.data_loader import load_market_data, load_candidate_data
from utils.db_utils import initialize_dbs, market_vector_db, candidate_db
from agents.market_benchmark_retriever import MarketBenchmarkRetrieverAgent
from agents.candidate_positioning_agent import CandidatePositioningAgent
from agents.compensation_generator_agent import CompensationGeneratorAgent
from agents.offer_justification_agent import OfferJustificationAgent

# Initialize databases once at the start of the application
# Streamlit reruns the script from top, so we use st.session_state to prevent re-initialization
if 'dbs_initialized' not in st.session_state:
    with st.spinner("Initializing databases and embedding market data... This might take a moment."):
        market_data = load_market_data()
        candidate_data = load_candidate_data()
        initialize_dbs(market_data, candidate_data)
        st.session_state.dbs_initialized = True
        st.session_state.market_vector_db = market_vector_db # Store in session state for agent access
        st.session_state.candidate_db = candidate_db # Store in session state for agent access

# Initialize agents
if 'agents_initialized' not in st.session_state:
    st.session_state.market_retriever_agent = MarketBenchmarkRetrieverAgent()
    st.session_state.candidate_positioning_agent = CandidatePositioningAgent()
    st.session_state.compensation_generator_agent = CompensationGeneratorAgent()
    st.session_state.offer_justification_agent = OfferJustificationAgent()
    st.session_state.agents_initialized = True

# --- Streamlit UI ---
st.title("💰 Intelligent Offer Personalizer (Agentic AI with RAG)")
st.markdown("""
This system leverages Agentic AI with Retrieval-Augmented Generation (RAG) to create
personalized and competitive compensation packages.
""")

# Ensure databases are initialized before accessing them
if not st.session_state.get('dbs_initialized'):
    st.error("Databases are not initialized. Please wait or refresh the page.")
    st.stop()

st.sidebar.header("Input Details")

with st.sidebar:
    st.subheader("Job Information")
    job_title = st.text_input("Job Title", "Software Engineer")
    experience_level = st.selectbox("Experience Level", ["Junior", "Mid-level", "Senior", "Lead", "Principal"])
    location = st.text_input("Location", "Bengaluru, India")
    industry = st.text_input("Industry", "Software")
    job_description = st.text_area("Job Description", """
    We are seeking a highly motivated and skilled Software Engineer to join our dynamic team in Bengaluru.
    The ideal candidate will have strong proficiency in Python and Java, experience with cloud platforms (AWS, Azure, GCP),
    and a solid understanding of microservices architecture. Responsibilities include designing, developing,
    and deploying scalable software solutions, collaborating with cross-functional teams, and contributing to
    all phases of the development lifecycle.
    """)

    st.subheader("Candidate Information")
    # Get candidate IDs safely
    candidate_ids = list(st.session_state.candidate_db.candidates.keys()) if st.session_state.candidate_db and st.session_state.candidate_db.candidates else []
    
    if not candidate_ids:
        st.error("No candidate data available. Please check your data files.")
        st.stop()
        
    candidate_id = st.selectbox(
        "Select Candidate ID (from simulated DB)",
        candidate_ids,
        index=0 if candidate_ids else None
    )
    st.info("You can inspect candidate data in `data/candidate_profiles.json`")

    st.subheader("Company Guidelines")
    company_guidelines = st.text_area("Company Specific Compensation Guidelines", """
    Our company offers competitive compensation tailored to market rates and individual performance.
    Base salaries are reviewed annually. Performance bonuses can range from 10% to 25% based on company and individual performance.
    Equity grants are typically provided for senior and critical roles, vesting over 4 years.
    Standard benefits include comprehensive health insurance, provident fund (PF), gratuity, employee stock purchase plan (ESPP),
    learning and development stipends, and a wellness program. We prioritize work-life balance and offer flexible working arrangements.
    """)


if st.sidebar.button("Generate Offer"):
    if not job_title or not experience_level or not location or not industry or not candidate_id:
        st.error("Please fill in all required Job and Candidate information.")
    else:
        st.subheader("Recommendation Process:")
        try:
            # 1. Market Benchmark Retrieval
            with st.spinner("Step 1: Retrieving Real-time Market Salary Benchmarks..."):
                market_benchmarks = st.session_state.market_retriever_agent.retrieve_benchmarks(
                    job_title, experience_level, location, industry
                )
                st.success("Market Benchmarks Retrieved!")
                st.expander("View Market Benchmarks").write(market_benchmarks)

            # 2. Candidate Positioning Analysis
            with st.spinner("Step 2: Analyzing Candidate Profile..."):
                candidate_profile_summary = st.session_state.candidate_positioning_agent.analyze_candidate_profile(
                    candidate_id, job_description
                )
                st.success("Candidate Profile Analyzed!")
                st.expander("View Candidate Analysis").write(candidate_profile_summary)

            # 3. Compensation Generation
            with st.spinner("Step 3: Generating Personalized Compensation Package..."):
                generated_offer = st.session_state.compensation_generator_agent.generate_compensation(
                    candidate_profile_summary, market_benchmarks, job_description, company_guidelines
                )
                st.success("Compensation Package Generated!")
                st.expander("View Raw Generated Offer").write(generated_offer)

            # 4. Offer Justification
            with st.spinner("Step 4: Generating Detailed Offer Justification..."):
                offer_justification = st.session_state.offer_justification_agent.justify_offer(
                    generated_offer, candidate_profile_summary, market_benchmarks, job_description, company_guidelines
                )
                st.success("Offer Justification Generated!")
                st.expander("View Offer Justification").write(offer_justification)

            st.markdown("---")
            st.subheader("✨ Final Compensation Offer ✨")
            st.markdown(generated_offer) # Display the final offer clearly

            st.subheader("📝 Offer Justification")
            st.markdown(offer_justification) # Display the final justification

        except Exception as e:
            st.error(f"An error occurred during the recommendation process: {e}")
            st.exception(e) # Display full traceback for debugging

else:
    st.info("Enter job and candidate details in the sidebar and click 'Generate Offer' to get started.")