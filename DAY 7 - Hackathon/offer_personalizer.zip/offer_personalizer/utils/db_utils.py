import faiss
import numpy as np
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.docstore.in_memory import InMemoryDocstore
from langchain.schema import Document
import os
from dotenv import load_dotenv
from typing import List, Dict, Optional
import json

load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if not GEMINI_API_KEY:
    raise ValueError("GEMINI_API_KEY not found in .env file. Please set it.")

# Initialize Google Generative AI Embeddings with API key
embeddings_model = GoogleGenerativeAIEmbeddings(
    model="models/embedding-001",
    google_api_key=GEMINI_API_KEY
)

class MarketVectorDB:
    """Manages FAISS for market salary data."""
    def __init__(self, data: List[Dict]):
        self.data = data
        self.docstore = InMemoryDocstore()
        self.vectorstore = self._initialize_faiss_vectorstore()

    def _initialize_faiss_vectorstore(self):
        """Creates and populates the FAISS vector store."""
        # Convert dictionary data to Document objects for LangChain
        docs = []
        for item in self.data:
            content = f"Job Title: {item.get('job_title', '')}, Experience: {item.get('experience_level', '')}, Location: {item.get('location', '')}, Industry: {item.get('industry', '')}, Median Salary: {item.get('median_base_salary', '')}"
            docs.append(Document(page_content=content, metadata=item))

        if not docs:
            print("No documents to add to FAISS.")
            return FAISS(embeddings_model.embed_query(""), faiss.IndexFlatL2(768), self.docstore) # Initialize empty FAISS
            
        print(f"Embedding {len(docs)} market data documents...")
        # Embed documents and add to FAISS
        # embeddings = embeddings_model.embed_documents([doc.page_content for doc in docs])
        # This will create and populate the FAISS index
        return FAISS.from_documents(docs, embeddings_model)

    def search(self, query: str, k: int = 1) -> List[Document]:
        """Performs a similarity search on the FAISS index."""
        if not self.vectorstore:
            return []
        return self.vectorstore.similarity_search(query, k=k)

class CandidateDB:
    """Simulates a MongoDB for candidate profiles."""
    def __init__(self, data: List[Dict]):
        self.candidates = {cand['id']: cand for cand in data}

    def find_one(self, candidate_id: str) -> Optional[Dict]:
        """Retrieves a single candidate profile by ID."""
        return self.candidates.get(candidate_id)

    def insert_one(self, candidate_data: Dict) -> None:
        """Inserts a new candidate profile (for future use)."""
        if 'id' not in candidate_data:
            candidate_data['id'] = f"cand_{len(self.candidates) + 1}"
        self.candidates[candidate_data['id']] = candidate_data
        print(f"Candidate {candidate_data['id']} added.")

# Initialize global DB instances
market_vector_db: Optional[MarketVectorDB] = None
candidate_db: Optional[CandidateDB] = None

def initialize_dbs(market_data: List[Dict], candidate_data: List[Dict]):
    """Initializes the global database instances."""
    global market_vector_db, candidate_db
    market_vector_db = MarketVectorDB(market_data)
    candidate_db = CandidateDB(candidate_data)
    print("Databases initialized.")

if __name__ == '__main__':
    from utils.data_loader import load_market_data, load_candidate_data

    # Load simulated data
    market_data = load_market_data()
    candidate_data = load_candidate_data()

    # Initialize databases
    initialize_dbs(market_data, candidate_data)

    # Test MarketVectorDB
    print("\nMarket DB Search Test:")
    query = "Software Engineer, Mid-level, Bengaluru"
    results = market_vector_db.search(query, k=2)
    for i, doc in enumerate(results):
        print(f"Result {i+1}:")
        print(f"  Content: {doc.page_content}")
        print(f"  Metadata: {json.dumps(doc.metadata, indent=2)}")

    # Test CandidateDB
    print("\nCandidate DB Retrieval Test:")
    cand_id = "cand_001"
    cand_profile = candidate_db.find_one(cand_id)
    if cand_profile:
        print(f"Found candidate {cand_id}: {json.dumps(cand_profile, indent=2)}")
    else:
        print(f"Candidate {cand_id} not found.")

    cand_id_new = "cand_999"
    new_candidate = {
        "id": cand_id_new,
        "name": "New Test User",
        "experience_years": 2,
        "skills": ["Python", "SQL"],
        "current_location": "Mumbai, India",
        "job_title_preference": "Junior Data Analyst"
    }
    candidate_db.insert_one(new_candidate)
    print(f"Retrieved new candidate: {candidate_db.find_one(cand_id_new)}")