import json
import os
from typing import List, Dict

def load_market_data(file_path: str = 'data/market_salary_data.json') -> List[Dict]:
    """Loads simulated market salary data from a JSON file."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Market data file not found: {file_path}")
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def load_candidate_data(file_path: str = 'data/candidate_profiles.json') -> List[Dict]:
    """Loads simulated candidate profiles from a JSON file."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Candidate data file not found: {file_path}")
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

if __name__ == '__main__':
    # Simple test to ensure data loads correctly
    market_data = load_market_data()
    candidate_data = load_candidate_data()
    print(f"Loaded {len(market_data)} market entries.")
    print(f"Loaded {len(candidate_data)} candidate profiles.")
    print("\nSample Market Data:")
    print(json.dumps(market_data[0], indent=2))
    print("\nSample Candidate Data:")
    print(json.dumps(candidate_data[0], indent=2))