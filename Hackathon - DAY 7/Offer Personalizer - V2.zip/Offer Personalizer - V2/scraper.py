import json
import os
import re
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

def clean_company_name(name: str) -> str:
    """
    Convert company name to Glassdoor-style URL slug.
    """
    return re.sub(r'\s+', '-', name.strip().title())

def scrape_glassdoor_benefits(company_name: str) -> list:
    """
    Scrapes benefits from Glassdoor for the given company using Playwright.
    """
    slug = clean_company_name(company_name)
    url = f"https://www.glassdoor.com/Benefits/{slug}-Benefits-EI_IE0.htm"  # EI_IE0 is placeholder ID

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context()
            page = context.new_page()
            print(f"🔍 Visiting: {url}")
            page.goto(url, timeout=60000)
            page.wait_for_timeout(5000)

            # Try common selectors (update if site changes)
            benefits = page.locator("li.gdBenefits-module__benefit").all_text_contents()
            if not benefits:
                benefits = page.locator("div.benefitDetails__BenefitStyle__benefitName").all_text_contents()

            browser.close()

            return benefits if benefits else ["No benefits found"]

    except PlaywrightTimeoutError:
        return ["Error: Timeout loading page"]
    except Exception as e:
        return [f"Error: {str(e)}"]

def save_benefits_to_json(company_list, output_file="company_benefits.json"):
    """
    Scrape and save benefits data for multiple companies.
    """
    results = {}
    for company in company_list:
        benefits = scrape_glassdoor_benefits(company)
        results[company] = benefits

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    print(f"\n✅ Scraped benefits saved to: {output_file}")

if __name__ == "__main__":
    companies = ["Google", "Microsoft", "Amazon", "Flipkart", "TCS"]
    save_benefits_to_json(companies)
