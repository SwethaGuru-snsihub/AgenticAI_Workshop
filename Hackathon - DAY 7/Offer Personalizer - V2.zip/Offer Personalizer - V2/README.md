Install dependencies:
 # pip install -r requirements.txt

 Create a `.env` file:
 # GOOGLE_API_KEY=your-gemini-api-key

 Run the app:
# streamlit run app.py

