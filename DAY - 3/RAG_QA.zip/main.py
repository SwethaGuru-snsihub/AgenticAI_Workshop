import os
import streamlit as st
from rag_core import RAGSystem
from dotenv import load_dotenv

# Load .env variables
load_dotenv()

# Load custom styles
def load_custom_css(file_path="styles.css"):
    with open(file_path) as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

def main():
    st.set_page_config(page_title="RAG QA SYSTEM", page_icon="🤖", layout="wide")
    load_custom_css()

    api_key = os.getenv("GEMINI_API_KEY", "")
    if 'rag_system' not in st.session_state:
        st.title("🤖 QA Assistant")
        st.info("📥 Upload PDFs or provide a directory to initialize the RAG system.")

        papers_dir = st.text_input("📁 Papers Directory", value="papers")
        uploaded_files = st.file_uploader("📤 Upload PDF files", type="pdf", accept_multiple_files=True)

        if st.button("🚀 Initialize System"):
            if not api_key:
                st.error("Please set GEMINI_API_KEY in your .env file.")
            else:
                rag = RAGSystem(api_key, papers_dir)
                if rag.initialize(uploaded_files):
                    st.session_state.rag_system = rag
                    st.success("✅ System initialized! You can now ask questions.")
                    st.rerun()
    else:
        st.success("✅ System Ready")
        question = st.text_area("💬 Ask a question:")
        if st.button("🔍 Get AI Answer") and question.strip():
            with st.spinner("Generating answer..."):
                result = st.session_state.rag_system.ask(question)
            st.markdown("### 💡 Answer")
            st.markdown(result["answer"].replace("\n", "<br>"), unsafe_allow_html=True)

            if result["sources"]:
                st.markdown("### 📚 Sources")
                for src in result["sources"]:
                    st.markdown(f"**{src['source']}** - Relevance: {src['score']:.2f}<br>{src['preview']}", unsafe_allow_html=True)

        if st.button("🔄 Reset"):
            del st.session_state.rag_system
            st.rerun()

if __name__ == "__main__":
    main()
