import os
import re
import faiss
import PyPDF2
import streamlit as st
from typing import List, Dict
from sentence_transformers import SentenceTransformer
import google.generativeai as genai

class RAGSystem:
    def __init__(self, api_key: str, papers_dir: str = "papers"):
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-1.5-flash')
        self.encoder = SentenceTransformer('all-MiniLM-L6-v2')
        self.papers_dir = papers_dir
        self.chunks = []
        self.index = None
        self.initialized = False

    def _load_pdf(self, file_path: str) -> str:
        try:
            with open(file_path, 'rb') as file:
                text = "".join(p.extract_text() for p in PyPDF2.PdfReader(file).pages)
                return re.sub(r'\s+', ' ', text).strip()
        except Exception as e:
            st.error(f"Error loading {file_path}: {e}")
            return ""

    def _load_pdf_from_bytes(self, file_bytes, filename: str) -> str:
        try:
            pdf_reader = PyPDF2.PdfReader(file_bytes)
            text = "".join(p.extract_text() for p in pdf_reader.pages)
            return re.sub(r'\s+', ' ', text).strip()
        except Exception as e:
            st.error(f"Error loading uploaded file {filename}: {e}")
            return ""

    def _chunk_text(self, text: str, source: str, size=1000, overlap=200) -> List[Dict]:
        words = text.split()
        return [
            {'text': ' '.join(words[i:i+size]), 'source': source, 'chunk_id': f"{source}_chunk_{i // (size-overlap)}"}
            for i in range(0, len(words), size - overlap)
        ]

    def initialize(self, uploaded_files=None) -> bool:
        files = []
        if os.path.exists(self.papers_dir):
            files += [os.path.join(self.papers_dir, f) for f in os.listdir(self.papers_dir) if f.endswith('.pdf')]
        
        total_files = files + uploaded_files if uploaded_files else files
        if not total_files:
            st.error("No PDF files found or uploaded.")
            return False

        self.chunks = []
        for f in files:
            text = self._load_pdf(f)
            if text:
                self.chunks.extend(self._chunk_text(text, os.path.basename(f)))

        if uploaded_files:
            for f in uploaded_files:
                text = self._load_pdf_from_bytes(f, f.name)
                if text:
                    self.chunks.extend(self._chunk_text(text, f.name))

        if not self.chunks:
            return False

        embeddings = self.encoder.encode([c['text'] for c in self.chunks])
        self.index = faiss.IndexFlatIP(embeddings.shape[1])
        faiss.normalize_L2(embeddings)
        self.index.add(embeddings.astype('float32'))
        self.initialized = True
        return True

    def ask(self, question: str, k: int = 3) -> Dict:
        if not self.initialized:
            return {'answer': "System not initialized", 'sources': []}

        query_emb = self.encoder.encode([question])
        faiss.normalize_L2(query_emb)
        scores, indices = self.index.search(query_emb.astype('float32'), k)

        context, sources = [], []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1: continue
            chunk = self.chunks[idx]
            context.append(f"Source: {chunk['source']}\n{chunk['text']}")
            sources.append({'source': chunk['source'], 'score': float(score), 'preview': chunk['text'][:200] + "..."})

        prompt = f"""Answer based on context below.

Context: {' '.join(context)}
Question: {question}
"""
        try:
            answer = self.model.generate_content(prompt).text
        except Exception as e:
            answer = f"Error generating answer: {e}"

        return {'answer': answer, 'sources': sources}
